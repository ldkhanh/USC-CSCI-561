package aiHW02;

public class TakeMove {

	private Game game;

	public TakeMove(Game game) {
		this.game = game;
	}

	public void move(Action move) {

		Cell square = move.getActions();
		Player player = game.getTurn();
		GameBoard board = game.getBoard();

		if (!board.isValidMove(square)) {
			throw new IllegalArgumentException("Invalid action");
		}

		if (isRaid(board, player, square.getX(), square.getY())) {
			doRaid(board, player, square);
		} else {
			doStake(board, player, square);
		}

		if (player == Player.PLAYERX) {
			game.setTurn(Player.PLAYERO);
		} else {
			game.setTurn(Player.PLAYERX);
		}
	}

	public boolean isRaid(GameBoard board, Player player, int x, int y) {
		String up = (x - 1 < 0) ? "." : board.getCell(x - 1, y).getState();
		String down = (x + 1 >= board.getSize()) ? "." : board.getCell(x + 1, y).getState();
		String left = (y - 1 < 0) ? "." : board.getCell(x, y - 1).getState();
		String right = (y + 1 >= board.getSize()) ? "." : board.getCell(x, y + 1).getState();

		if (up.equals(player.getState()) || down.equals(player.getState()) || left.equals(player.getState())
				|| right.equals(player.getState())) {
			return true;
		} else {
			return false;
		}
	}

	public void doStake(GameBoard board, Player player, Cell square) {
		board.setOccupied(player, board.getCell(square.getX(), square.getY()));
		this.game.setMoveType("Stake");
		this.game.setNextMove(square.getPos());
	}

	public void doRaid(GameBoard board, Player player, Cell square) {
		int i = 0;
		int x = square.getX();
		int y = square.getY();
		board.setOccupied(player, board.getCell(x, y));
		String up = (x - 1 < 0) ? "." : board.getCell(x - 1, y).getState();
		String down = (x + 1 >= board.getSize()) ? "." : board.getCell(x + 1, y).getState();
		String left = (y - 1 < 0) ? "." : board.getCell(x, y - 1).getState();
		String right = (y + 1 >= board.getSize()) ? "." : board.getCell(x, y + 1).getState();

		if (up.equals(player.other().getState())) {
			board.setOccupied(player, board.getCell(x - 1, y));
			board.subtractPlPoint(player.other(), board.getCell(x - 1, y).getValue());
			i++;
		}
		if (down.equals(player.other().getState())) {
			board.setOccupied(player, board.getCell(x + 1, y));
			board.subtractPlPoint(player.other(), board.getCell(x + 1, y).getValue());
			i++;
		}
		if (left.equals(player.other().getState())) {
			board.setOccupied(player, board.getCell(x, y - 1));
			board.subtractPlPoint(player.other(), board.getCell(x, y - 1).getValue());
			i++;
		}
		if (right.equals(player.other().getState())) {
			board.setOccupied(player, board.getCell(x, y + 1));
			board.subtractPlPoint(player.other(), board.getCell(x, y + 1).getValue());
			i++;
		}
		if (i != 0) {
			this.game.setMoveType("Raid");
			this.game.setNextMove(square.getPos());
		} else {
			this.game.setMoveType("Stake");
			this.game.setNextMove(square.getPos());
		}
	}

}
