package aiHW02;

public class Cell implements Cloneable{
	private final int i,j;
	private int value;
	private String state;
	
	public Cell(int i, int j) {
		this.i = i;
		this.j = j;
	}
	
	public Cell(int i, int j, int value, String state) {
		this.i = i;
		this.j = j;
		this.value = value;
		this.state = state;
	}
	
	@Override
	public Cell clone() {
		return new Cell(this.i, this.j, this.value, this.state);
	}
	
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		if (value < 1 || value > 99)
			this.value = 0;
		else 
			this.value = value;
	}
	
	public String getPos(){
		return (char)(j+65) + Integer.toString(i + 1);
	}
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getX(){
		return this.i;
	}
	public int getY() {
		return this.j;
	}

}
