package aiHW02;



public class AlphaBetaMode implements AgentMode {

	private int maxD;
	private Player currPlayer;
	private int alpha = Integer.MIN_VALUE;
	private int beta = Integer.MAX_VALUE;
	
	public AlphaBetaMode(int depth) {
		this.maxD = depth;
	}
	@Override
	public Action getMove(GameBoard board, Player player) {
		this.currPlayer = player;
		Action move = maxValue(board,player, 0, "root", alpha, beta);
		return move;
	}
	
	private Action maxValue(GameBoard board,Player player,int depth, String previousState, int alpha, int beta)  {
		if (board.isComplete() || depth >= maxD && !player.isPlayer(previousState)) {
			Action move = new Action();
			move.setScore(score(board, currPlayer));
//			System.out.println("Complete: "+previousState + "," + depth + "," + move.getScore()+","+alpha+","+beta);
			return move;
		}
		
//		System.out.println(previousState + "," + depth + ",-Infinity,"+alpha+","+beta);
		
		Action maxMove = new Action();
		maxMove.setScore(Integer.MIN_VALUE);
		if (depth == 1) {
			alpha = Integer.MIN_VALUE;
			beta = Integer.MAX_VALUE;
		}
		String maxType = "Stake";
		
		for (Cell cell : board.getValidMove(player)) {
			Action move = new Action(cell);		
			Game game = new Game(board.clone(), player);
//			System.out.println(game.getBoard());
			game.move(move);
			
			int newDepth = depth + (player.isPlayer(previousState) ? 0 : 1); // check later
			
			if (game.getTurn() == player) {
				Action nextMove = maxValue(game.getBoard(), player, newDepth, player.getCellPos(cell), alpha, beta);
				move.setActions(nextMove.getActions());
				move.setScore(nextMove.getScore());
			} else {
				move.setScore(minValue(game.getBoard(), player.other(), newDepth, player.getCellPos(cell), alpha, beta).getScore());
			}
			
			if (beta <= move.getScore()) {
				return move;
			}
			
			alpha = Math.max(alpha, move.getScore());
			
			if (maxMove.getScore() < move.getScore()) {
				maxMove = move;
				maxType = game.getMoveType();
			} else if (maxMove.getScore() == move.getScore()) {
				if (maxType.equals("Raid") && game.getMoveType().equals("Stake")){
					maxMove = move;
					maxType = game.getMoveType();
				}	
			}
		}
		return maxMove;
	}
	
	private Action minValue(GameBoard board,Player player, int depth, String previousState, int alpha, int beta)  {
		if (board.isComplete() || depth >= maxD && !player.isPlayer(previousState)) {
			Action move = new Action();
			move.setScore(score(board, currPlayer));
//			System.out.println("Complete: "+previousState + "," + depth + "," + move.getScore()+","+alpha+","+beta);
			return move;
		}
		
//		System.out.println(previousState + "," + depth + ",-Infinity,"+alpha+","+beta);
		
		Action minMove = new Action();
		minMove.setScore(Integer.MAX_VALUE);
		if (depth == 1) {
			alpha = Integer.MIN_VALUE;
			beta = Integer.MAX_VALUE;
		}
		String minType = "Stake";
		
		for (Cell cell : board.getValidMove(player)) {
			Action move = new Action(cell);		
			Game game = new Game(board.clone(), player);
//			System.out.println(game.getBoard());
			game.move(move);
			
			int newDepth = depth + (player.isPlayer(previousState) ? 0 : 1); // check later
			
			if (game.getTurn() == player) {
				Action nextMove = minValue(game.getBoard(), player, newDepth, player.getCellPos(cell), alpha, beta);
				move.setActions(nextMove.getActions());
				move.setScore(nextMove.getScore());
			} else {
				move.setScore(maxValue(game.getBoard(), player.other(), newDepth, player.getCellPos(cell), alpha, beta).getScore());
			}
			
			if (alpha >= move.getScore()) {
				return move;
			}
			
			beta = Math.min(beta, move.getScore());
			
			if (move.getScore() < minMove.getScore()) {
				minMove = move;
				minType = game.getMoveType();
			} else if (minMove.getScore() == move.getScore()) {
				if (minType.equals("Raid") && game.getMoveType().equals("Stake")){
					minMove = move;
					minType = game.getMoveType();
				}
			}
		}
		return minMove;
	}	
	private int score(GameBoard board, Player player) {
		return board.getPlPoint(player) - board.getPlPoint(player.other());
	}
}
