package aiHW02;

public class Action {
	
	private Cell actions;
	private int score = Integer.MIN_VALUE;
	
	public Action(){}
	public Action(Cell action) {
		setActions(action);
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public Cell getActions() {
		return actions;
	}
	public void setActions(Cell actions) {
		this.actions = actions;
	}
}
