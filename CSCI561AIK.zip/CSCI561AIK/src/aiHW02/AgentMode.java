package aiHW02;

public interface AgentMode {
	public Action getMove(GameBoard board, Player player);
}
