package aiHW02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GameBoard implements Cloneable {

	private final Cell[][] board;
	private final int n; // size of board
	private int plPoint = 0;
	private int opPoint = 0;

	public GameBoard(int n) {
		this.n = n;
		this.board = new Cell[this.n][this.n];
		this.plPoint = 0;
		this.opPoint = 0;
	}
	public GameBoard(Cell[][] board, int plPoint, int opPoint) {
		this.n = board[0].length;

		this.board = new Cell[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				this.board[i][j] = board[i][j].clone();
			}
		}
		
		this.plPoint = plPoint;
		this.opPoint = opPoint;
	}
	@Override
	public GameBoard clone() {
		return new GameBoard(board.clone(), this.plPoint, this.opPoint);
	}
	public boolean equals(GameBoard b) {
		return Arrays.equals(this.board, b.board);
	}

	public void setCell(int i, int j) {
		// remember check valid cell
		Cell cell = new Cell(i, j);
		board[i][j] = cell;
	}

	public Cell getCell(int i, int j) {
		// reminder check valid cell;
		return board[i][j];
	}

	public Cell[][] getBoard() {
		return this.board;
	}

	public boolean isComplete() {
		for (int i = 0; i < getSize(); i++)
			for (int j = 0; j < getSize(); j++) {
				if (this.board[i][j].getState().equals("."))
					return false;
			}
		return true;
	}

	public int getSize() {
		return n;
	}

	public void setOccupied(Player player, Cell cell) {
		int i = cell.getX();
		int j = cell.getY();
		if (i >= this.n || j >= this.n || i < 0 || j < 0)
			throw new IllegalArgumentException("Invalid cell = " + cell.getPos());
		board[i][j].setState(player.getState());
		addPlPoint(player, board[i][j].getValue());
	}

	public int getPlPoint(Player player) {
		if (player == Player.PLAYERX)
			return this.plPoint;
		else
			return this.opPoint;
	}

	public void addPlPoint(Player player, int point) {
		if (player == Player.PLAYERX) {
			this.plPoint += point;
		} else {
			this.opPoint += point;
		}
	}

	public void subtractPlPoint(Player player, int point) {
		if (player == Player.PLAYERX)
			this.plPoint -= point;
		else
			this.opPoint -= point;
	}

	public Player getWinner() {
		if (this.getPlPoint(Player.PLAYERX) == this.getPlPoint(Player.PLAYERO))
			return null;
		else if (this.getPlPoint(Player.PLAYERX) > this.getPlPoint(Player.PLAYERO))
			return Player.PLAYERX;
		else
			return Player.PLAYERO;
	}

	public List<Cell> getValidMove(Player player) {
		List<Cell> moves = new ArrayList<>();
		for (int i = 0; i < getSize(); i++)
			for (int j = 0; j < getSize(); j++) {
				if (isValidMove(board[i][j])) {
					moves.add(board[i][j]);
				}
			}
		return moves;
	}

	public boolean isValidMove(Cell cell) {
		if (cell != null) {
			int x = cell.getX();
			int y = cell.getY();
			if (x < 0 || (x >= this.n) || (y < 0) || (y >= this.n) || !cell.getState().equals("."))
				return false;
			else
				return true;
		} else {
			return false;
		}
	}

	@Override
	public String toString() {
		final StringBuilder str = new StringBuilder();

		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				str.append(this.board[i][j].getState());
			}
			if (i != getSize() - 1)
				str.append("\n");
		}
		return str.toString();
	}

}
