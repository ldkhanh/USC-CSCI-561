package aiHW02;

public class Game {
	private GameBoard board;
	private AgentMode playerM = null;
	private AgentMode opponentM = null;
	private Player turn = Player.PLAYERX;
    private String moveType;
    private String nextMove;
	
	public Game() {}
	public Game(GameBoard board, Player turn) {
		this.setBoard(board);
		this.setTurn(turn);
	}
	public GameBoard getBoard() {
		return board;
	}
	public void setBoard(GameBoard board) {
		this.board = board;
	}
	public Player getTurn() {
		return turn;
	}
	public void setTurn(Player turn) {
		this.turn = turn;
	}
	public Player getWinner() {
		return board.getWinner();
	}
	
	public void move(final Action move) {
		new TakeMove(this).move(move);		
	}
	
	// Play the game until it is done.
	public void play(){
		while (!board.isComplete()){
			implement();
		}
	}
	// Play each turn
	public void implement() {
		Action thisMove;		
		if (turn == Player.PLAYERX) {
			thisMove = playerM.getMove(board, Player.PLAYERX);
		} else {
			thisMove = opponentM.getMove(board, Player.PLAYERO);
		}
		if (!board.isComplete() )
			move(thisMove);
	}
	public void setMode(Player player, AgentMode mode) {
		if (player == Player.PLAYERX)
			this.playerM = mode;
		else 
			this.opponentM = mode;
	}
	public String getMoveType() {
		return moveType;
	}
	public void setMoveType(String moveType) {
		this.moveType = moveType;
	}
	public String getNextMove() {
		return nextMove;
	}
	public void setNextMove(String nextMove) {
		this.nextMove = nextMove;
	}
}













