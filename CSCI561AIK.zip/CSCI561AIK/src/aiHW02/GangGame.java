package aiHW02;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class GangGame {
	private static long startTime = System.currentTimeMillis();
	private Game game;
	private Player player;
	private AgentMode algoMode;
	private int N;
	private String Mode, Play;
	private int depth;
	private GameBoard board;
	private boolean inputS;

	public GangGame() {
	}

	public GangGame(String file) {
		inputS = input(file);
//		inputS = input(file+"/input.txt");
		if (inputS) {
			player = Player.getPlayer(Play);
			algoMode = getMode(Mode, depth);
			game = new Game(board, player);
			game.setBoard(board);
			game.setTurn(player);
			game.setMode(player, algoMode);
			game.implement();

			// ---- Print board----
			System.out.println(N);
			System.out.println(Mode);
			System.out.println(Play);
			System.out.println(depth);
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					System.out.format("%-3d", board.getCell(i, j).getValue());
				}
				System.out.println();
			}
			// --- End print input---

			System.out.println("Solution: ");
			System.out.println(game.getNextMove() + " " + game.getMoveType());
			System.out.println(board);

			// Write output file
			output(game.getNextMove() + " " + game.getMoveType() + "\n", board.toString());

//			output2(file,game.getNextMove() + " " + game.getMoveType() + "\n", board.toString());

		}
	}

	public static void main(String[] args) {
		new GangGame("input.txt");

		long endTime = System.currentTimeMillis();
		System.out.println("It took " + (endTime - startTime) + " milliseconds");
	}

	private boolean input(String fileName) {
		BufferedReader br = null;
		try {
			String line, lValue[];
			br = new BufferedReader(new FileReader(fileName));
			// ----Get board size-----
			if ((line = br.readLine()) != null)
				line = line.replaceAll("\\s", "");
			else {
				System.out.println("Invalid input");
				return false;
			}
			if (line.matches("[0-9]+") && line.length() > 0)
				N = Integer.parseInt(line);
			else
				return false;
			if (N > 26) {
				System.out.println("Invalid input Size");
				return false;
			}
			// ----board size-----

			Mode = br.readLine().replaceAll("\\s", "");
			Play = br.readLine().replaceAll("\\s", "");
			// ----Get depth -----
			if ((line = br.readLine()) != null)
				line = line.replaceAll("\\s", "");
			else {
				System.out.println("Invalid input");
				return false;
			}
			if (line.matches("[0-9]+") && line.length() > 0)
				depth = Integer.parseInt(line);
			else
				depth = 1; // Depth node should evaluation later

			// ----depth-----

			board = new GameBoard(N);
			// --- Make board
			// ----Extract value -----
			for (int i = 0; i < N; i++) {
				line = br.readLine();
				lValue = line.split(" ");
				for (int j = 0; j < lValue.length; j++) {
					int iPoint = Integer.parseInt(lValue[j]);
					board.setCell(i, j);
					board.getCell(i, j).setValue(iPoint);
				}
			}
			// ----Extract state-----
			for (int i = 0; i < N; i++) {
				line = br.readLine();
				for (int j = 0; j < line.length(); j++) {
					String stateV = Character.toString(line.charAt(j));
					board.getCell(i, j).setState(stateV);
					if (line.charAt(j) != '.') {
						board.addPlPoint(Player.getPlayer(board.getCell(i, j).getState()),
								board.getCell(i, j).getValue());
					}
				}
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}

	private void output(String move, String boardState) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt"), "utf-8"))) {
			writer.write(move);
			writer.write(boardState);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	private void output2(String path,String move, String boardState) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path+"/output.txt"), "utf-8"))) {
			writer.write(move);
			writer.write(boardState);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private static AgentMode getMode(String algoMode, int depth) {
		switch (algoMode) {
		case "MINIMAX":
			return new MinimaxMode(depth);
		case "ALPHABETA":
			return new AlphaBetaMode(depth);
		default:
			throw new IllegalArgumentException("Invalid input");
		}
	}

}
