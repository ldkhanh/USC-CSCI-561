package aiHW02;

public class MinimaxMode implements AgentMode {

	private int maxD;
	private Player currPlayer;

	public MinimaxMode(int depth) {
		this.maxD = depth;
	}

	@Override
	public Action getMove(GameBoard board, Player player) {

//		System.out.println("Node,Depth,Value");
		this.currPlayer = player;
		Action move = maxValue(board, player, 0, "root");
		
		return move;
	}

	private Action maxValue(GameBoard board, Player player, int depth, String previousState) {
		if (board.isComplete() || depth >= maxD && !player.isPlayer(previousState)) {
			Action move = new Action();
			move.setScore(score(board, currPlayer));
//			System.out.println("MaxComplete: "+previousState + "," + depth + "," + move.getScore());
			return move;
		}

//		System.out.println("OutMax "+previousState + "," + depth + ",-Infinity");
		
		Action maxMove = new Action();
		maxMove.setScore(Integer.MIN_VALUE);
		String maxType = "Stake";
				
		for (Cell cell : board.getValidMove(player)) {			
			Action move = new Action(cell);		
			Game game = new Game(board.clone(), player);
			game.move(move);
//			System.out.println(game.getBoard());

			int newDepth = depth + (player.isPlayer(previousState) ? 0 : 1); 
			if (game.getTurn() == player) {
				Action nextMove = maxValue(game.getBoard(), player, newDepth, player.getCellPos(cell));
				move.setActions(nextMove.getActions());
				move.setScore(nextMove.getScore());
			} else {
				move.setScore(minValue(game.getBoard(), player.other(), newDepth, player.getCellPos(cell)).getScore());
			}
			
			if (maxMove.getScore() < move.getScore()) {
				maxMove = move;
				maxType = game.getMoveType();
			} else if (maxMove.getScore() == move.getScore()) {
				if (maxType.equals("Raid") && game.getMoveType().equals("Stake")){
					maxMove = move;
					maxType = game.getMoveType();
				}	
			}
//			System.out.println("inMax: "+previousState + "," + depth + "," + maxMove.getScore());
		}
		return maxMove;
	}

	private Action minValue(GameBoard board, Player player, int depth, String previousState) {
		if (board.isComplete() || depth >= maxD && !player.isPlayer(previousState)) {
			Action move = new Action();
			move.setScore(score(board, currPlayer));
			
//			System.out.println("minComplete: "+previousState + "," + depth + "," + move.getScore());

			return move;
		}
		
//		System.out.println("OutMin "+ previousState + "," + depth + ",Infinity");

		Action minMove = new Action();
		minMove.setScore(Integer.MAX_VALUE);
		String minType = "Stake";
		
		for (final Cell cell : board.getValidMove(player)) {			
			Action move = new Action(cell);
			Game game = new Game(board.clone(), player);
			game.move(move);
//			System.out.println(game.getBoard());

			int newDepth = depth + (player.isPlayer(previousState) ? 0 : 1);

			if (game.getTurn() == player) {
				Action nextMove = minValue(game.getBoard(), player, newDepth, player.getCellPos(cell));
				move.setActions(nextMove.getActions());
				move.setScore(nextMove.getScore());
			} else {
				move.setScore(maxValue(game.getBoard(), player.other(), newDepth, player.getCellPos(cell)).getScore());
			}
			if (move.getScore() < minMove.getScore()) {
				minMove = move;
				minType = game.getMoveType();
			} else if (minMove.getScore() == move.getScore()) {
				if (minType.equals("Raid") && game.getMoveType().equals("Stake")){
					minMove = move;
					minType = game.getMoveType();
				}
				
			}
//			System.out.println("inMin: "+previousState + "," + depth + "," + minMove.getScore());
		}
		return minMove;
	}
	private int score(GameBoard board, Player player) {
		return board.getPlPoint(player) - board.getPlPoint(player.other());
	}
	
}
