package aiHW02;

public enum Player {

	PLAYERX("X"),
	PLAYERO("O");
	
	private final String state;
	Player(String state) {
		this.state = state;
	}
	
	
	public Player other() {
		return (this == PLAYERX) ? PLAYERO : PLAYERX;
	}
	
	public static Player getPlayer(String pl) {
		return pl.equals("X") ? PLAYERX : PLAYERO;
	}
	public String getState() {
		return this.state;
	}
	public String getCellPos(Cell cell) {
		return this.state + cell.getPos();
	}
	public boolean isPlayer(String pl) {
		return this.state.equals(pl.charAt(0));
	}
}
