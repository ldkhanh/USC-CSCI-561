package aiHW02;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class GeneratorTestCases {
	private final static Random random = new Random(System.nanoTime());
	public static void main(String[] args) {
//		createInput(100);
		createOutput();
		
	}
	private static void createInput(int Size) {
		for (int i = 0; i < Size; i++) {
			int n = randInt(5,15);
			File file = new File("/Users/khanh/Documents/workspace/CSCI561AIK/TestCases/Test" + (i + 152));
			if (!file.exists()) {
				if (file.mkdir()) {
					
					System.out.println("Created! : " + file.getPath());
					try (Writer writer = new BufferedWriter(
							new OutputStreamWriter(new FileOutputStream(file.getPath() + "/input.txt"), "utf-8"))) {
						writer.write(Integer.toString(n)+"\n");
						writer.write("ALPHABETA\n");
						writer.write("O\n");
						writer.write(Integer.toString(randInt(1,6))+"\n");
						//--- board value
						for (int j = 0; j < n; j++) {
							for (int k = 0; k < n; k++) {
								int temp = randInt(1,99);
								if (k != n-1)
									writer.write(Integer.toString(temp)+" ");
								else 
									writer.write(Integer.toString(temp));
							}
							writer.write("\n");
						}
						//--- board state
						char[][] bState = new char[n][n];
						int m = randInt(0,n*n);
						for (int t = 0; t < m; t++) {
							int x = randInt(0,n-1);
							int y = randInt(0,n-1);
							int z = randInt(0,100);
							bState[x][y] = ((z%3) == 1) ? 'X' : 'O'; 
						}
						for (int j = 0; j < n; j++) {
							for (int k = 0; k < n; k++) {
								if (bState[j][k] == 'X' || bState[j][k] == 'O')
									writer.write(bState[j][k]);
								else
									writer.write(".");
							}
							if (j != n-1)
								writer.write("\n");
						}
					} catch (IOException ex) {
						ex.printStackTrace();
					}
					
				} else {
					System.out.println("Failed to create directory!");
				}
			}
		}
	}
	
	private static int randInt(final int min, final int max) {
		return random.nextInt(max - min + 1) + min;
	}
	
	private static void createOutput() {
		try {
			List<File> file = Files.walk(Paths.get("/Users/khanh/Documents/workspace/CSCI561AIK/TestCases"))
			        .filter(Files::isRegularFile)
			        .map(Path::toFile)
			        .collect(Collectors.toList());
			String temp = "";
			for(int i = 0; i < file.size(); i++ ){
				temp = file.get(i).getName();
				if (temp.endsWith(".txt"))
					if (temp.equals("input.txt")) {
						System.out.println(file.get(i).toString() + " Index : " +i);
						
						new GangGame(file.get(i).getParent());
						
					}
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
