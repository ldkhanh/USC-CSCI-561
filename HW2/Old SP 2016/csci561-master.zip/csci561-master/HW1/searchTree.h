/**
    CSCI 561 Foundations of Artificial Intelligence
    University of Southern California
    Title: searchTree.h

    @author David Swick - Student Number 9205616636
    @version 1.0
*/

#ifndef SEARCHTREE_H
#define SEARCHTREE_H

#include <iostream>
#include <fstream>
#include <queue>
#include <stack>
#include <string>
#include <vector>
#include <set>
#include <sstream>
#include <algorithm>
#include <cstdio>

class searchTree
{
    public:
        struct node{
            int depth;
            bool visited;
            std::string state;
            std::string path;
            unsigned int index;
            std::vector<node*> children;
			node* parent;
            int g;
            int f;
            int h;
			bool explored;
			bool enq;
			node(int depth, bool visited, std::string state, unsigned int index, node* parent, int g, int f) : 
				depth(depth), 
				visited(visited),
				state(state),
				index(index),
				parent(parent),
				g(g),
				f(f),
				h(h) {
				explored = false; enq = false;
			};
            ~node(){};
        };
        struct MyComparator{
            bool operator()(node* a, node* b){
                return a->f > b->f;
            }
        };

        searchTree();
        virtual ~searchTree();
        void BreadthFirstSearch();
        void DepthFirstSearch();
        void UniformCostSearch();
        void AstarSearch();
        void buildDataStructures(std::ifstream& myfile);
        void startSearch();
        bool goalTest(const std::string& state);
        void setRootNode(const std::string& state);
        void setGoalState(const std::string& state);
        void displayParameters();
    protected:
    private:
        node* _rootNode;
        std::string _goalState;
        std::string _strategy;
        std::queue<node*> _queue;
        std::priority_queue<node*, std::vector<node*>, MyComparator> _priQueue;
        std::stack<node*> _stack;
        std::vector<node*> _nodes;
        std::vector<std::string> _nodeStates;
        std::vector<std::vector<int>> _edges;
        int numNodes;

        void writeOutput(const std::string& result);
};

#endif // SEARCHTREE_H
