/**
    CSCI 561 Foundations of Artificial Intelligence
    University of Southern California
    Title: main.cpp

    @author David Swick - Student Number 9205616636
    @version 1.0
*/

#include <iostream>
#include "searchTree.h"

using namespace std;

/**
    searchTree Class Constructor.

    @param None
    @return None
*/
searchTree::searchTree()
{
    _nodes.clear();
    _nodeStates.clear();
    numNodes = 0;
    _rootNode = NULL;
}


/**
    searchTree Class Destructor

    @param None
    @return None
*/
searchTree::~searchTree()
{
    for(std::vector<node*>::iterator i = _nodes.begin(); i != _nodes.end(); ++i) delete *i;
    _nodes.clear();
    _nodeStates.clear();
}


/**
    Write the final result to output.txt

    @param Result: Result string of the search
    @return None
*/
void searchTree::writeOutput(const std::string& result)
{
    // TODO: Output path result to output.txt
    std::ofstream outputFile("output.txt", std::ios::out);
    if(outputFile.is_open())
    {
        outputFile << result;
        outputFile.close();
    }
    else std::cout << "Failed to open output.txt\n";

    // std::cout << result << std::endl;
}


/**
    Sets the <GOAL STATE> for the search tree

    @param state: Name of the <GOAL STATE>
    @return None
*/
void searchTree::displayParameters()
{
//    std::cout << "Number of Nodes: " << this->numNodes << std::endl;
//    std::cout << "<START STATE>: " << this->_rootNode->state << std::endl;
//    std::cout << "<GOAL STATE>: " << this->_goalState << std::endl;
//
//    std::cout << "<STATE LIST>: \n";
    for(unsigned int i=0; i<_nodes.size(); i++)
    {
        std::cout << _nodes.at(i)->state << ", index: " << _nodes.at(i)->index << std::endl;
        std::cout << "      children: \n";
        for(unsigned int j=0; j<_nodes.at(i)->children.size(); j++)
        {
            std::cout << "          " << _nodes.at(i)->children.at(j)->state << std::endl;
        }
    }

    std::cout << "\n\n";

    for(int i=0; i<numNodes; i++)
    {
        for(int j=0; j<numNodes; j++)
            std::cout << "[ " << _edges[i][j] << " ] ";

        std::cout << std::endl;
    }

    std::cout << "\n\n";
}


/**
    Sets the <GOAL STATE> for the search tree

    @param state: Name of the <GOAL STATE>
    @return None
*/
void searchTree::setGoalState(const std::string& state)
{
    this->_goalState = state;
}


/**
    searchTree

    @param None
    @return None
*/
void searchTree::setRootNode(const std::string& state)
{
	this->_rootNode = new node(0, false, state, 0, nullptr, 0, 0);

    this->_nodes.push_back(this->_rootNode);
    this->_nodeStates.push_back(this->_rootNode->state);

    numNodes++;
}


/**
    Tests of the goal state has been reached in the search tree

    @param state: The state to be tested
    @return bool: TRUE if goal state has been reached
*/
bool searchTree::goalTest(const std::string& state)
{
    bool returnValue = false;

    if(!this->_goalState.compare(state))
        returnValue = true;

    return returnValue;
}


/**
    Builds the data structures for the search algorithms to operate

    @param None
    @return None
*/
void searchTree::buildDataStructures(std::ifstream& myfile)
{
    std::string line;
    std::string n1;
    std::string n2;
    std::string cost;

    std::getline(myfile, line); this->_strategy = line;
    std::getline(myfile, line); setRootNode(line);
    std::getline(myfile, line); setGoalState(line);

    std::getline(myfile, line); int numTrafficLines = std::stoi(line);
    for(int i=0; i<numTrafficLines; i++)
    {
        std::getline(myfile, line); std::stringstream ss(line);
        ss >> n1; ss >> n2; ss >> cost;

        unsigned int n1_pos = std::find(_nodeStates.begin(), _nodeStates.end(), n1) - _nodeStates.begin();
        if(n1_pos >= _nodeStates.size())
        {
			node* tempNode = new node(-1, false, n1, n1_pos, nullptr, 0, 0);

            _nodeStates.push_back(n1);
            _nodes.push_back(tempNode);
            numNodes++;
        }

		unsigned int n2_pos = std::find(_nodeStates.begin(), _nodeStates.end(), n2) - _nodeStates.begin();
        if(n2_pos >= _nodeStates.size())
        {
			node* tempNode = new node(-1, false, n2, n2_pos, nullptr, 0, 0);

            _nodeStates.push_back(n2);
            _nodes.push_back(tempNode);
            numNodes++;
        }

        _nodes.at(n1_pos)->children.push_back(_nodes.at(n2_pos));

        _edges.resize(numNodes);
        for(int i=0; i<numNodes; i++)
            _edges[i].resize(numNodes);

        _edges[n1_pos][n2_pos] = std::stoi(cost);
    }

	if (!myfile.eof())
	{
		std::getline(myfile, line); int numSunTrafficLines = std::stoi(line);
		for (int i = 0; i < numSunTrafficLines; i++)
		{
			std::getline(myfile, line); std::stringstream ss(line);
			ss >> n1; ss >> cost;

			unsigned int n1_pos = std::find(_nodeStates.begin(), _nodeStates.end(), n1) - _nodeStates.begin();
			_nodes.at(n1_pos)->h = std::stoi(cost);
		}
	}
}


/**
    Performs the Breadth First Search algorithm from START STATE --> GOAL STATE

    @param None
    @return None
*/
void searchTree::BreadthFirstSearch()
{
	std::string resultPath;

    this->_rootNode->visited = true;
    this->_rootNode->depth = 0;
    this->_rootNode->path += this->_rootNode->state + " " + std::to_string(this->_rootNode->depth) + "\n";

    _queue.push(this->_rootNode);

    while(!_queue.empty())
    {
        node* testNode = _queue.front(); _queue.pop();
        if(goalTest(testNode->state))
        {
            resultPath = testNode->path;
            break;
        }

        if(!testNode->children.empty())
        {
            for(unsigned int i=0; i<testNode->children.size(); i++)
            {
                node* child = testNode->children.at(i);
                if(child->visited == false)
                {
                    child->visited = true;
                    child->depth = testNode->depth + 1;
                    child->path = testNode->path + child->state + " " + std::to_string(child->depth) + "\n";
                    _queue.push(child);
                }
            }
        }
    }

	writeOutput(resultPath);
}


/**
    Performs the Depth First Search algorithm from START STATE --> GOAL STATE

    @param None
    @return None
*/
void searchTree::DepthFirstSearch()
{
	std::string resultPath;

    _rootNode->visited = true;
    _rootNode->depth = 0;
    _rootNode->path += _rootNode->state + " " + std::to_string(_rootNode->depth) + "\n";

    _stack.push(_rootNode);

    while(!_stack.empty())
    {
		node* testNode = _stack.top();

        if(goalTest(testNode->state))
        {
			resultPath = testNode->path;
            break;
        }
        else
        {
			_stack.pop();
            for(unsigned int i = testNode->children.size(); i --> 0;)
            {
                node* child = testNode->children.at(i);
                if(child->visited == false)
                {
                    child->visited = true;
                    child->depth = testNode->depth+1;
                    child->path = testNode->path + child->state + " " + std::to_string(child->depth) + "\n";
                    _stack.push(child);
                }
            }
        }
    }

	writeOutput(resultPath);
}


/**
    Performs the Uniform Cost Search algorithm from START STATE --> GOAL STATE

    @param None
    @return None
*/
void searchTree::UniformCostSearch()
{
    std::string resultPath;

	_rootNode->path += _rootNode->state + " " + std::to_string(this->_rootNode->depth) + "\n";
	_rootNode->enq = true;
	_priQueue.push(_rootNode);

	while (!_priQueue.empty())
	{
		node* testNode = _priQueue.top(); _priQueue.pop();
		testNode->enq = false;

		if (goalTest(testNode->state))
		{
			resultPath = testNode->path;
			break;
		}
		else if (testNode->explored == false)
		{
			testNode->explored = true;
			for (unsigned int i = 0; i < testNode->children.size(); i++)
			{
				node* child = testNode->children.at(i);
				if (child->explored == false)
				{
					int g = testNode->g + _edges[testNode->index][child->index];
					int h = 0;
					int f = g + h;

					if (child->enq == false)
					{
						child->g = g;
						child->f = f;
						child->path = testNode->path + child->state + " " + std::to_string(child->g) + "\n";
						child->depth = testNode->depth + 1;
						child->parent = testNode;
						child->enq = true;
						_priQueue.push(child);
					}
					else if (g < child->g)
					{
						child->g = g;
						child->f = f;
						child->path = testNode->path + child->state + " " + std::to_string(child->g) + "\n";
						child->depth = testNode->depth + 1;
						child->parent = testNode;
					}
				}
			}
		}
	}

    // std::cout << "\nResults\n";
    writeOutput(resultPath);
}


/**
    Performs the A* Search algorithm from START STATE --> GOAL STATE

    @param None
    @return None
*/
void searchTree::AstarSearch()
{
	std::string resultPath;

	_rootNode->path += _rootNode->state + " " + std::to_string(this->_rootNode->depth) + "\n";
	_rootNode->enq = true;
	_priQueue.push(_rootNode);

	while (!_priQueue.empty())
	{
		node* testNode = _priQueue.top(); _priQueue.pop();
		testNode->enq = false;

		if (goalTest(testNode->state))
		{
			resultPath = testNode->path;
			break;
		}
		else if (testNode->explored == false)
		{
			testNode->explored = true;
			for (unsigned int i = 0; i < testNode->children.size(); i++)
			{
				node* child = testNode->children.at(i);
				if (child->explored == false)
				{
					int g = testNode->g + _edges[testNode->index][child->index];
					int h = child->h;
					int f = g + h;

					if (child->enq == false)
					{
						child->g = g;
						child->f = f;
						child->path = testNode->path + child->state + " " + std::to_string(child->g) + "\n";
						child->depth = testNode->depth + 1;
						child->parent = testNode;
						child->enq = true;
						_priQueue.push(child);
					}
					else if(g < child->g)
					{
						child->g = g;
						child->f = f;
						child->path = testNode->path + child->state + " " + std::to_string(child->g) + "\n";
						child->depth = testNode->depth + 1;
						child->parent = testNode;
					}
				}
			}
		}
	}

	// std::cout << "\nResults\n";
	writeOutput(resultPath);
}


/**
    Initiates the search algorithm assuming the problem definition has been established.

    @param strategy: The search algorithm to be implemented.
    @return None
*/
void searchTree::startSearch()
{
    if(!_strategy.compare("BFS")) this->BreadthFirstSearch();
    else if(!_strategy.compare("DFS")) this->DepthFirstSearch();
    else if(!_strategy.compare("UCS")) this->UniformCostSearch();
    else if(!_strategy.compare("A*")) this->AstarSearch();
    else std::cout << "Invalid Search Type Specified\n";
}

/*****************************************************************************
                                    MAIN
******************************************************************************/
int main()
{
    searchTree *g = new searchTree();

    std::ifstream myfile("input.txt");
    if(myfile.is_open())
    {
        g->buildDataStructures(myfile);
        myfile.close();

        // g->displayParameters();
        g->startSearch();
    }
    else
    {
        std::cout << "Input File Open FAILURE\n";
        delete g;

		// std::getchar();
        exit(1);
    }

    delete g;

	// std::getchar();
    return 0;
}
