/**
	CSCI 561 Foundations of Artificial Intelligence
	University of Southern California
	Title: homework11.cpp
	Project: HW2 Minimax and Alpha-Beta Pruning

	@author David Swick - Student Number 9205616636
	@version 1.0
*/

#include "searchTree.h"


/**
	Function Description

	@param None
	@return None
*/
Board::Board(int depth, int N)
{
	this->depth = depth;
	this->N = N;
	this->gameScore = 0;
	this->utilVal = 0;
	this->MIN = false;
	this->MAX = false;
	this->TERMINAL = false;

	this->boardState.resize(N);
	for (int i = 0; i < N; i++)
		this->boardState[i].resize(N);
}


/**
	Function Description

	@param None
	@return None
*/
Board::~Board()
{
	//std::cout << "Deleting Board Node\n";
}


/**
	Function Description

	@param None
	@return None
*/
std::string Board::boardStateToString()
{
	std::string result;

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < N; j++)
		{
			result += boardState[i][j].piece;
		}
		result += "\n";
	}

	return result;
}


/**
Function Description

@param None
@return None
*/
void Board::updateBoardWithMove(std::pair<int,int> move)
{
	std::vector<std::pair<int, int>> raidPositions;
	int x = move.first; int y = move.second;
	bool raidAvailable = false;

	for (int dx = -1; dx <= 1; ++dx)
	{
		if ((dx == 0))
		{
			for (int dy = -1; dy <= 1; ++dy)
			{
				if ((dy != 0) && (y + dy >= 0) && (y + dy < N))
				{
					if (!this->boardState[x + dx][y + dy].piece.compare(this->youplay))
					{
						raidAvailable = true;
					}
				}
			}
		}
		else if ((x + dx >= 0) && (x + dx < N))
		{
			if (!this->boardState[x + dx][y].piece.compare(this->youplay))
			{
				raidAvailable = true;
			}
		}
	}

	if (raidAvailable)
	{
		for (int dx = -1; dx <= 1; ++dx)
		{
			if ((dx == 0))
			{
				for (int dy = -1; dy <= 1; ++dy)
				{
					if ((dy != 0) && (y + dy >= 0) && (y + dy < N))
					{
						if (!this->boardState[x + dx][y + dy].piece.compare(this->theyplay))
						{
							this->movetype = "Raid";
							this->boardState[x + dx][y + dy].piece = this->youplay;
						}
					}
				}
			}
			else if ((x + dx >= 0) && (x + dx < N))
			{
				if (!this->boardState[x + dx][y].piece.compare(this->theyplay))
				{
					this->movetype = "Raid";
					this->boardState[x + dx][y].piece = this->youplay;
				}
			}
		}
	}
}


/**
	Function Description

	@param None
	@return None
*/
searchTree::searchTree()
{
	this->alpha = std::numeric_limits<int>::min();
	this->beta = std::numeric_limits<int>::max();
}


/**
	Function Description

	@param None
	@return None
*/
searchTree::~searchTree()
{
	//std::cout << "Deleting Search Tree\n";
}


/**
	Function Description

	@param None
	@return None
*/
void searchTree::printResults()
{
	std::cout << this->move << " " << this->movetype << std::endl;
	std::cout << this->nextBoardState << std::endl;
}


/**
	Function Description

	@param None
	@return None
*/
int searchTree::alphaBeta(Board* currentNode, int a, int b, bool playerMax)
{
	int bestVal;

	if (currentNode->TERMINAL || currentNode->depth == 0)
	{
		bestVal = currentNode->gameScore;
	}
	else
	{
		if (playerMax)
		{
			bestVal = a;
			for (unsigned int i = 0; i < currentNode->possibleMovesList.size(); i++)
			{
				Board child(currentNode->depth + 1, currentNode->N); //currentNode->children.push_back(&child);
				buildGameBoard(&child, currentNode, currentNode->possibleMovesList[i]);

				int childVal = alphaBeta(&child, bestVal, b, false);
				bestVal = std::max(bestVal, childVal);

				if (b <= bestVal)
					break;
			}
		}
		else
		{
			bestVal = b;
			for (unsigned int i = 0; i < currentNode->possibleMovesList.size(); i++)
			{
				Board child(currentNode->depth + 1, currentNode->N); //currentNode->children.push_back(&child);
				buildGameBoard(&child, currentNode, currentNode->possibleMovesList[i]);

				int childVal = alphaBeta(&child, a, bestVal, true);
				bestVal = std::min(bestVal, childVal);

				//currentNode->children.pop_back();

				if (bestVal <= a)
					break;
			}
		}
	}

	return bestVal;
}


/**
Function Description

@param None
@return None
*/
int searchTree::miniMax(Board* currentNode, bool playerMax)
{
	int bestVal;

	if (currentNode->TERMINAL || currentNode->depth == 0)
	{
		bestVal = currentNode->gameScore;
	}
	else
	{
		if (playerMax)
		{
			bestVal = std::numeric_limits<int>::min();
			for (unsigned int i = 0; i < currentNode->possibleMovesList.size(); i++)
			{
				Board* child = new Board(currentNode->depth + 1, currentNode->N); currentNode->children.push_back(child);
				buildGameBoard(child, currentNode, currentNode->possibleMovesList[i]);

				int childVal = miniMax(child, false);
				bestVal = std::max(bestVal, childVal);

				currentNode->children.pop_back();
				delete child;
			}
		}
		else
		{
			bestVal = std::numeric_limits<int>::max();
			for (unsigned int i = 0; i < currentNode->possibleMovesList.size(); i++)
			{
				Board* child = new Board(currentNode->depth + 1, currentNode->N); currentNode->children.push_back(child);
				buildGameBoard(child, currentNode, currentNode->possibleMovesList[i]);

				int childVal = miniMax(child, true);
				bestVal = std::min(bestVal, childVal);

				currentNode->children.pop_back();
				delete child;
			}
		}
	}

	return bestVal;
}


/**
	Function Description

	@param None
	@return None
*/
void searchTree::initializeGame(std::ifstream& inputFile)
{
	if (inputFile.is_open())
	{
		std::string line; 
		int N;

		std::getline(inputFile, line); 
		N = std::stoi(line);

		std::getline(inputFile, line);
		if (!line.compare("ALPHABETA")) this->MODE = GAMEMODE::ALPHABETA;
		else if (!line.compare("MINIMAX")) this->MODE = GAMEMODE::MINIMAX;
		else if (!line.compare("COMPETITION")) this->MODE = GAMEMODE::COMPETITION;

		std::getline(inputFile, line);
		if (!line.compare("X"))
		{
			this->YOUPLAY = "X";
			this->YouPlay = PLAYER::PlayerX;
			this->TheyPlay = PLAYER::PlayerO;
			this->THEYPLAY = "O";
		}
		else
		{
			this->YOUPLAY = "O";
			this->YouPlay = PLAYER::PlayerO;
			this->TheyPlay = PLAYER::PlayerX;
			this->THEYPLAY = "X";
		}

		std::getline(inputFile, line); 
		this->MAXDEPTH = std::stoi(line);

		this->rootNode = new Board(0, N);
		this->rootNode->youplay = THEYPLAY;
		this->rootNode->theyplay = YOUPLAY;
		this->rootNode->MAX = true;

		// Setup a NxN game board and setup initial board state
		for (int i = 0; i < N; i++)
		{
			std::getline(inputFile, line); std::stringstream ss(line);
			for (int j = 0; j < N; j++)
			{
				ss >> this->rootNode->boardState[i][j].value;
				this->rootNode->boardState[i][j].index = charVal(j + 1) + std::to_string(i+1);
			}
		}
		for (int i = 0; i < N; i++)
		{
			std::getline(inputFile, line); std::istringstream ss(line);
			std::vector<char> pieces(line.begin(), line.end());
			for (int j = 0; j < N; j++)
			{
				//ss >> this->rootNode->boardState[i][j].piece;
				this->rootNode->boardState[i][j].piece = pieces[j];
				if (!this->rootNode->boardState[i][j].piece.compare("."))
				{
					rootNode->possibleMovesList.push_back(std::pair<int, int>(i, j));
				}
			}
		}

		if (rootNode->possibleMovesList.empty())
			rootNode->TERMINAL = true;

		//printParams(rootNode);
		calculateGameScore(rootNode);
	}
}


/**
	Function Description

	@param None
	@return None
*/
void searchTree::findBestMove(Board* node, int currentDepth, Board *&result)
{
	result = nullptr;

	int bestScore = std::numeric_limits<int>::min();
	for(unsigned int i=0; i<rootNode->possibleMovesList.size(); i++)
	{
		Board* child = new Board(rootNode->depth + 1, rootNode->N); rootNode->children.push_back(child);
		buildGameBoard(child, rootNode, rootNode->possibleMovesList[i]);
		//printGameBoard(child);

		int val;

		if (MODE == GAMEMODE::ALPHABETA)
			val = alphaBeta(child, alpha, beta, false);

		else if (MODE == GAMEMODE::MINIMAX)
			val = miniMax(child, false);

		if (val > bestScore || (val == bestScore && !child->movetype.compare("Stake") && !result->movetype.compare("Raid")))
		{
			bestScore = val;
			result = child;
		}
	}
}


/**
Function Description

@param None
@return None
*/
void searchTree::buildGameBoard(Board* childNode, Board* parentNode, std::pair<int, int> potentialMove)
{
	childNode->boardState = parentNode->boardState;
	childNode->possibleMovesList = parentNode->possibleMovesList;
	childNode->possibleMovesList.erase(std::remove(childNode->possibleMovesList.begin(), childNode->possibleMovesList.end(), potentialMove));

	if (childNode->possibleMovesList.empty() || childNode->depth >= MAXDEPTH)
		childNode->TERMINAL = true;

	std::string temp = parentNode->youplay;
	childNode->youplay = parentNode->theyplay;
	childNode->theyplay = temp;

	childNode->MAX = !parentNode->MAX;
	childNode->MIN = parentNode->MAX;

	int r = potentialMove.first;
	int c = potentialMove.second;

	childNode->boardState[r][c].piece = childNode->youplay;
	childNode->moveindex = childNode->boardState[r][c].index;
	childNode->movetype = "Stake";

	childNode->updateBoardWithMove(potentialMove);

	calculateGameScore(childNode);
}


/**
Function Description

@param None
@return None
*/
void searchTree::deleteGameTree(Board* node)
{
	if (!node->children.empty())
	{
		unsigned int numChildren = node->children.size();
		for (unsigned int i = 0; i < numChildren; i++)
		{
			Board* child = node->children[i];
			deleteGameTree(child);
		}
		delete node;
	}
	else
		delete node;
}


/**
Function Description

@param None
@return None
*/
void searchTree::playGame()
{
	Board* resultNode = nullptr; 

	if (rootNode->TERMINAL == false)
		findBestMove(rootNode, rootNode->depth, resultNode);
	else
		resultNode = rootNode;

	printGameBoard(resultNode);

	deleteGameTree(this->rootNode);
}


/**
	Function Description

	@param None
	@return None
*/
void searchTree::printParams(Board* currentNode)
{
	std::cout << "N: " << std::to_string(currentNode->N) << std::endl;
	std::cout << "MODE: " << MODE << std::endl;
	std::cout << "YOUPLAY: " << YOUPLAY << std::endl;
	std::cout << "MAXDEPTH: " << std::to_string(MAXDEPTH) << std::endl << std::endl;
}


/**
Function Description

@param None
@return None
*/
void searchTree::printGameBoard(Board* currentNode)
{
	//std::cout << currentNode->moveindex << " " << currentNode->movetype << /*", Score: " << currentNode->gameScore << ", Depth: " << currentNode->depth <<*/ "\n";
	//std::cout << currentNode->boardStateToString() << "\n";

	std::ofstream outputFile("output.txt");
	if (outputFile.is_open()) outputFile << currentNode->moveindex << " " << currentNode->movetype << "\n" << currentNode->boardStateToString(); outputFile.close();


	//std::cout << "Number of possible moves: " << currentNode->possibleMovesList.size() << "\n";

	//for (unsigned int i = 0; i < currentNode->possibleMovesList.size(); i++)
	//	std::cout << "Possible index: [ " << currentNode->possibleMovesList[i].first << " " << currentNode->possibleMovesList[i].second << " ]\n";
}


/**
Function Description

@param None
@return None
*/
void searchTree::evaluateBoard(Board* node)
{
	node->utilVal = node->gameScore; // Just testing this
}


/**
Function Description

@param None
@return None
*/
void searchTree::calculateGameScore(Board* node)
{
	node->gameScore = 0;

	for (int i = 0; i < node->N; i++)
	{
		for (int j = 0; j < node->N; j++)
		{
			if (!node->boardState[i][j].piece.compare(YOUPLAY))
				node->gameScore += node->boardState[i][j].value;
			else if(node->boardState[i][j].piece.compare("."))
				node->gameScore -= node->boardState[i][j].value;
		}
	}
}


/*****************************************************************************
									MAIN
 *****************************************************************************/
int main()
{
	searchTree *tree;

	std::ifstream inputFile;
	inputFile.exceptions(std::ifstream::failbit | std::ifstream::badbit);

	try
	{
		tree = new searchTree();

		inputFile.open("input.txt");

		tree->initializeGame(inputFile);
		tree->playGame();
	}
	catch (std::ifstream::failure e)
	{
		std::cerr << e.what() << std::endl;
	}

	delete tree;
	//system("pause");
}
