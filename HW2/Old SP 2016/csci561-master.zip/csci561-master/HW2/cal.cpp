#include <iostream>

int main()
{
	std::cout << "Hello CAL" << std::endl;
}
