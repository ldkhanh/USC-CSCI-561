/**
	CSCI 561 Foundations of Artificial Intelligence
	University of Southern California
	Title: Board.h
	Project: HW2 Minimax and Alpha-Beta Pruning

	@author David Swick - Student Number 9205616636
	@version 1.0
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <queue>
#include <algorithm>
#include <limits>
#include <assert.h>
#include <tuple>

class Board
{
public:
	Board(int depth, int N);
	~Board();

	struct square {
		std::string piece;
		int value;
		std::string index;
		square() : piece(" "), value(0), index(" "){};
	};
	
	int utilVal, depth, N, gameScore;
	bool MIN, MAX, TERMINAL;
	std::string movetype, moveindex, youplay, theyplay;

	std::vector<std::vector<square>> boardState;
	std::vector<Board*> children;
	std::vector<std::pair<int, int>> possibleMovesList;

	std::string boardStateToString();
	void updateBoardWithMove(std::pair<int, int> move);

private:

};