/**
	CSCI 561 Foundations of Artificial Intelligence
	University of Southern California
	Title: searchTree.h
	Project: HW2 Minimax and Alpha-Beta Pruning

	@author David Swick - Student Number 9205616636
	@version 1.0
*/

#include "Board.h"

class searchTree
{
public:
	searchTree();
	~searchTree();

	enum GAMEMODE {
		MINIMAX,
		ALPHABETA,
		COMPETITION
	};

	enum PLAYER {
		PlayerX,
		PlayerO
	};

	int alpha, beta, MAXDEPTH;
	Board* rootNode;
	std::string nextBoardState, move, movetype, YOUPLAY, THEYPLAY;
	PLAYER YouPlay, TheyPlay;
	GAMEMODE MODE;

	int alphaBeta(Board* currentNode, int a, int b, bool playerMax);
	int miniMax(Board* currentNode, bool playerMax);
	void printParams(Board* currentNode);
	void printGameBoard(Board* currentNode);
	void initializeGame(std::ifstream& inputFile);
	void printResults();
	void playGame();
	void findBestMove(Board* node, int currentDepth, Board *&result);
	void deleteGameTree(Board* node);

private:
	void buildGameBoard(Board* childNode, Board* parentNode, std::pair<int, int> potentialMove);
	void evaluateBoard(Board* node);
	void calculateGameScore(Board* node);
	char charVal(int val) { return "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[val - 1]; };
};