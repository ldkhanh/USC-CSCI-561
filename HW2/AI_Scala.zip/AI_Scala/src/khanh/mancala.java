package khanh;

import java.io.*;
import java.util.*;

public class mancala {
	
	static int val=0;
	static int actualPlayer;
	
	class returnclass {
		int val;
		gameSetup returnstate;
	}
	
	class gameSetup {
		boolean replay = false;
		private int[] boardstatePlayer2 = new int[0];
		private int[] boardstatePlayer1 = new int[0];
		private int stone2;
		private int stone1;
		
		public void setboardSize(int size) {
			boardstatePlayer2 = new int[size];
			boardstatePlayer1 = new int[size];
		}
		
		public gameSetup(String[] val2, String[] val1, int stone_2, int stone_1) {
			setboardSize(val1.length);
			for (int i = 0; i < val1.length; i++) {
				boardstatePlayer1[1] = Integer.parseInt(val1[i]);
			}
			
			for (int i = 0; i < val2.length; i++) {
				boardstatePlayer2[i] = Integer.parseInt(val2[i]);
			}
			
			stone1 = stone_1;
			stone2 = stone_2;
		}
		
		public gameSetup() {}
	}
	
	public static gameSetup Initialize(Scanner input) {
		String[] val2 = input.nextLine().split(" ");
		String[] val1 = input.nextLine().split(" ");
		
		int stone2 = Integer.parseInt((String) input.nextLine());
		int stone1 = Integer.parseInt((String) input.nextLine());
		
		gameSetup g = new mancala().new gameSetup(val2, val1, stone2, stone1);
		
		return g;
	}
	
	public static int eval(gameSetup g, int Player) {
		int eval = 0;
		
		if (Player == 1) {
			val = g.stone1 - g.stone2;
		} else {
			val = g.stone2 - g.stone1;
		}
		
		return actualPlayer == Player ? val:-1*val;
	}
	
	public static gameSetup getState(gameSetup g, int i, int player) {
		
		gameSetup tempobj = copyParent(g);
		int boardSize = tempobj.boardstatePlayer1.length - 1;
		
		if (player == 1) {
			int stoneInPit = tempobj.boardstatePlayer1[i];
			tempobj.boardstatePlayer1[i] = 0;
			
			int index = i;
			while (stoneInPit != 0) {
				tempobj.replay = false;
				for (int j = index + 1; j <= boardSize; j++) {
					if (stoneInPit > 0) {
						tempobj.boardstatePlayer1[j]++;
						stoneInPit--;
						
						if (stoneInPit == 0 && tempobj.boardstatePlayer1[j] == 1) {
							tempobj.stone1++;
							tempobj.boardstatePlayer1[j] = 0;
							tempobj.stone1 += tempobj.boardstatePlayer2[j];
							tempobj.boardstatePlayer2[j] = 0;
						}
					}
				}
				
				if (stoneInPit > 0) {
					tempobj.stone1++;
					stoneInPit--;
					if (stoneInPit == 0) {
						tempobj.replay = true;
					}
				}
				if (stoneInPit > 0) {
					for (int k = boardSize; k >= 0; k--) {
						if (stoneInPit > 0) {
							tempobj.boardstatePlayer2[k]++;
							stoneInPit--;
						}
					}
				}
				if (stoneInPit > 0) {
					index = -1;
				}
			}
		} else {
			int stoneInPit = tempobj.boardstatePlayer2[i];
			tempobj.boardstatePlayer2[i] = 0;
			int index = i;
			while (stoneInPit != 0) {
				tempobj.replay = false;
				for (int j = index -1; j >= 0; j--) {
					if (stoneInPit > 0) {
						tempobj.boardstatePlayer2[j]++;
						stoneInPit--;
						if (stoneInPit == 0 && tempobj.boardstatePlayer2[j] == 1) {
							tempobj.stone2++;
							tempobj.boardstatePlayer2[j] = 0;
							tempobj.stone2 += tempobj.boardstatePlayer1[j];
							tempobj.boardstatePlayer1[j] = 0;
						}
					}
				}
				
				if (stoneInPit > 0) {
					tempobj.stone2++;
					stoneInPit--;
					if (stoneInPit == 0) {
						tempobj.replay = true;
					}
				}
				if (stoneInPit > 0) {
					for (int k = 0; k <= boardSize; k++) {
						if (stoneInPit > 0) {
							tempobj.boardstatePlayer1[k]++;
							stoneInPit--;
						}
					}
				}
				if (stoneInPit > 0) {
					index = boardSize + 1;
				}
			}
		}
		
		// check for game over
		int countB1 = 0;
		int countB2 = 0;
		if (isgameOver(tempobj,player)) {
			for (int u = 0; u <= boardSize; u++) {
				countB1 += tempobj.boardstatePlayer1[u];
				tempobj.boardstatePlayer1[u] = 0;
				countB2 += tempobj.boardstatePlayer2[u];
				tempobj.boardstatePlayer2[u] = 0;
			}
			if (player == 1) {
				tempobj.stone2 += countB1 + countB2;
			} else {
				tempobj.stone1 += countB1 + countB2;
			}
		}
		return tempobj;
	}
	
	// Profit value
	public static String profitValue(int value) {
		if (value == Integer.MAX_VALUE)
			return "Infinity";
		if (value == Integer.MIN_VALUE) 
			return "-Infinity";
		
		return String.valueOf(value);
	}
	
	public static void writeLog(String child, int level, int profit, PrintWriter traverse_log, int task, Integer alpha, Integer beta) throws IOException {
		if (task == 2) {
			traverse_log.print("\n" + child + "," + level + "," + profitValue(profit));
		} else if (task == 3) {
			traverse_log.print("\n" + child + "," + level + "," + profitValue(profit) + "," + profitValue(alpha) + "," + profitValue(beta));
		}
	}
	
	// Get legal Moves
	public static ArrayList<Integer> getChildrenPits(gameSetup g, int player) {
		ArrayList<Integer> return_result = new ArrayList<Integer>();
		if (player == 1) {
			for (int i = 0; i < g.boardstatePlayer1.length; i++) {
				if (g.boardstatePlayer1[i] != 0) {
					return_result.add(i);
				}
			}
		}else {
			for (int i = 0; i < g.boardstatePlayer2.length; i++) {
				if (g.boardstatePlayer2[i] != 0) {
					return_result.add(i);
				}
			}
		}
		return return_result;
	}
	
	//end
	
	//Check for Game over
	
	// end game over
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
