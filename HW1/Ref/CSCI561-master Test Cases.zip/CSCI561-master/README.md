# 这是一个CSCI561 at USC的测试程序

将被测试文件放在`benchmark.py`同级目录下，并重命名为`test_target`

# 使用要求

如果你使用了这套程序，最好回报测试结果增强测试准确度(不回报也无所谓)

回报测试结果的话，请将你的`results`文件夹提交为pull request

# System Requirement

POSIX兼容

# 感谢

测试85到164由 [tenohiranokubomini](mailto:hectorilles@gmail.com) 提供
