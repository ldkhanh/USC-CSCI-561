package graphL;

import java.io.*;

public class GraphApp {
	
	public static void main(String[] args) {
		try {
			File file = new File("data.txt");
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line = br.readLine();
			
			if (line != null) {
				String[] nodeNames = line.split(" ");
				int[] nodes = new int[nodeNames.length];
				for (int i = 0; i < nodes.length; ++i){
					nodes[i] = Integer.parseInt(nodeNames[i]);
				}
				
				Graph g = new Graph(nodes);
				
				while ((line = br.readLine()) != null) {
					String[] tokens = line.split(" ");
					int v1 = Integer.parseInt(tokens[0]);
					int v2 = Integer.parseInt(tokens[1]);
					
					g.addNeighbor(v1, v2);
					g.addNeighbor(v2, v1);
				}
			}
			
			br.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
