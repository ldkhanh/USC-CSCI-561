package graphL;

import java.util.*;
public class Test {

	public static void main(String[] args){
		
		System.out.println("////------------Priority Queue----------////");

		Queue<String> q = new PriorityQueue<String>();
		
		q.offer("B");
		q.offer("E");
		q.offer("I");
		q.offer("A");
		
		Iterator<String> tt = q.iterator();
		while (tt.hasNext()){
			System.out.print( tt.next()+ " ");
		}
		System.out.println();
		System.out.print(q.poll() + " "+q.poll() + " "+ q.poll() + " " + q.poll());
		System.out.println();
		
		
	}
}
