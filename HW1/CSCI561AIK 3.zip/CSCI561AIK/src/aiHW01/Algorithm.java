package aiHW01;

import java.io.*;
import java.util.*;


public class Algorithm {
	
	private Queue<Node> frontierB;
	private Deque<Node> frontierD;
	private Queue<Node> frontierU;
	private Queue<Node> exploredSet;
	
	
	public Algorithm(){
		this.frontierB = new LinkedList<Node>();
		this.frontierD = new LinkedList<Node>();
		this.exploredSet = new LinkedList<Node>();
		
	}
	
	public void BFS(Graph problem) {
		
		frontierB.offer(problem.getStartS());
		Node node, new_node;
		ArrayList<Node> childNode = new ArrayList<Node>();
		
		while (true) {
			if (frontierB.isEmpty())
				return;
			
			////-----------Print frontier----------///
			Iterator<Node> tt = frontierB.iterator();
			System.out.print("Fronier list: ");
			while (tt.hasNext()){
				System.out.print("  " + tt.next().getState());
			}
			System.out.println();
			//--------------------------///
			
			
			node = this.frontierB.poll();
			
			if (problem.getGoalS().getState().equals(node.getState())){
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			childNode = expandNode(node, problem);
			System.out.print("  Add child : ");
			
			for (int i = 0; i < childNode.size(); i++){
				new_node = childNode.get(i);
				if (!frontierB.contains(new_node) && !exploredSet.contains(new_node)){
					new_node.setParent(node);
					new_node.setDepth(node.getDepth()+1);
					frontierB.offer(new_node);
					System.out.print("{ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"}  ");
				}
				else {
//					System.out.print("Not[ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"]  ");
				}
			} 
			System.out.println("");
		}
		
	}
	
	public void DFS(Graph problem) {
		
		frontierD.push(problem.getStartS());
		Node node, new_node;
		ArrayList<Node> childNode = new ArrayList<Node>();
		
		while (true) {
			if (frontierD.isEmpty())
				return;
		
			////-----------Print frontier----------///
			Iterator<Node> tt = frontierD.iterator();
			System.out.print("Fronier list: ");
			while (tt.hasNext()){
				System.out.print("  " + tt.next().getState());
			}
			System.out.println();
			//--------------------------///
			
			node = frontierD.pop();			
			if (problem.getGoalS().getState().equals(node.getState())){
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			childNode = expandNode(node, problem);
			Collections.reverse(childNode);
			
			System.out.print("  Add child : ");
			for (int i = 0; i < childNode.size(); i++){
				new_node = childNode.get(i);
				if (!frontierD.contains(new_node) && !exploredSet.contains(new_node)){
					new_node.setParent(node);
					new_node.setDepth(node.getDepth()+1);
					frontierD.push(new_node);
					System.out.print("{ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"}  ");
				}
				else {
//					System.out.print("Not[ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"]  ");
				}
			} 
			System.out.println("");
		}
	}
	
	public void UCS(Graph problem) {
		this.frontierU = new PriorityQueue<Node>(problem.getNumNodes(), compUCS);
		frontierU.offer(problem.getStartS());
		Node node = problem.getStartS();
		Node new_node = null,temp = null;
		ArrayList<Node> childNode = new ArrayList<Node>();
		
		while (true) {
			if (frontierU.isEmpty())
				return;
			
			////-----------Print frontier----------///
			Iterator<Node> tt = frontierU.iterator();
			System.out.println();
			System.out.print("Fronier list1: ");
			
			while (tt.hasNext()){
				temp = tt.next();
				System.out.print("  " + temp.getState()+temp.getGCost());
			}
			System.out.println();
			//--------------------------///
			
			node = this.frontierU.poll();
			if (problem.getGoalS().getState().equals(node.getState())){
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			childNode = expandNode(node, problem);
			
			System.out.print("  Add child : ");
			
			for (int i = 0; i < childNode.size(); i++){
				new_node = childNode.get(i);
				if (!frontierU.contains(new_node) && !exploredSet.contains(new_node)){
					insertNodeU(node,new_node);
					System.out.print("{ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"}  ");
				}
				else {
//					System.out.print("Not[ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"]  ");
					
					if (frontierU.contains(new_node)) {		
						temp = findNode(frontierU,new_node);
						if (temp.getGCost() > new_node.getGCost()){
							frontierU.remove(temp);
							updateNodeU(node,new_node,problem);
							System.out.println("Update1 {" + new_node.getState() + "<--" + new_node.getParent().getState()+"}");
						}
					} 
					else if (exploredSet.contains(new_node)){
						temp = findNode(exploredSet,new_node);
						if (temp.getGCost() > new_node.getGCost()){
							exploredSet.remove(temp);
							updateNodeU(node,new_node,problem);
							System.out.println("Update2 {" + new_node.getState() + "<--" + new_node.getParent().getState()+"}");
						}
					}
				}
			} 
			System.out.println("");
			
			SortedSet<Node> sorter = new TreeSet<Node>(new Comparator<Node>() {
				@Override
				public int compare(Node a, Node b) {
					if (a.getGCost() == b.getGCost()){
						return (a.getPriority() - b.getPriority());
					}
					return ((a.getGCost()) - (b.getGCost()));
				}
			});
			
			sorter.addAll(frontierU);
			frontierU.removeAll(sorter);
			frontierU.addAll(sorter);	
			
		}
		
	}
	
	public void Astar(Graph problem) {
		this.frontierU = new PriorityQueue<Node>(problem.getNumNodes(), compA);
		frontierU.offer(problem.getStartS());
		Node node = problem.getStartS();
		Node new_node,temp;
		ArrayList<Node> childNode = new ArrayList<Node>();
		
		while (true) {
			if (frontierU.isEmpty())
				return;
			
			////-----------Print frontier----------///
			Iterator<Node> tt = frontierU.iterator();
			System.out.print("A* Fronier list: ");
			
			while (tt.hasNext()){
				temp = tt.next();
				System.out.print("  " + temp.getState()+temp.getfCost());
			}
			System.out.println();
			//--------------------------///
			
			node = this.frontierU.poll();
			
			if (problem.getGoalS().getState().equals(node.getState())){
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			childNode = expandNode(node, problem);
			System.out.print("  Add child : ");
			
			for (int i = 0; i < childNode.size(); i++){
				new_node = childNode.get(i);
				if (!frontierU.contains(new_node) && !exploredSet.contains(new_node)){
					insertNodeU(node,new_node);
					System.out.print("{ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"}  ");
				}
				else {
//					System.out.print("Not[ "+new_node.getState()+" <-- "+new_node.getParent().getState()+"]  ");
					if (frontierU.contains(new_node)) {	
						temp = findNode(frontierU,new_node);
						if (temp.getfCost()  > new_node.getfCost()){
							frontierU.remove(temp);
							updateNodeU(node,new_node,problem);
						}
					} 
					else if (exploredSet.contains(new_node)){
						temp = findNode(exploredSet,new_node);
						if (temp.getfCost()  > new_node.getfCost()){
							exploredSet.remove(temp);
							updateNodeU(node,new_node,problem);
						}
					}
					
				}
			} 
			System.out.println("");
			
			SortedSet<Node> sorter = new TreeSet<Node>(new Comparator<Node>() {
				@Override

				public int compare(Node a, Node b) {
					if (a.getfCost() == b.getfCost()) {
						return (a.getPriority() - b.getPriority());
					}
					return (a.getfCost() - b.getfCost());
				}
			});

			sorter.addAll(frontierU);
			frontierU.clear();
			frontierU.addAll(sorter);
		}
	}
	
	private void insertNodeU(Node node, Node new_node){
		
		Node temp = new Node(new_node.getId(), new_node.getPriority(), new_node.getState(), new_node.getGCost(), new_node.getHCost());
		temp.setParent(node);
		temp.setDepth(node.getDepth() +1);
		
		frontierU.offer(temp);
		new_node.setParent(node);
		new_node.setDepth(node.getDepth() + 1);
	}
	
	private void updateNodeU(Node node, Node new_node,Graph g){
		
		Node temp = new Node(new_node.getId(), g.getNumNodes(), new_node.getState(), new_node.getGCost(), new_node.getHCost());
//		temp.setPriority(g.getNumNodes());			// put this node to lower priority
		temp.setParent(node);
		temp.setDepth(node.getDepth() +1);
		
		frontierU.offer(temp);
		new_node.setParent(node);
		new_node.setDepth(node.getDepth() + 1);
	}
	
	private ArrayList<Node> expandNode(Node node, Graph g) {
		ArrayList<Node> sucessors = new ArrayList<Node>();
		Node s;
		int adj[][] = g.getAdjG();
		ArrayList<Node> listNodes = g.getListNodes();
		
/*		System.out.print("List Nodes 1: ");
		for (int i = 0; i < listNodes.size(); i++)
			System.out.print("{"+listNodes.get(i).getState() +  ":" + listNodes.get(i).getGCost() + "} ");
		System.out.println();*/
		
		
		int k = node.getId();
		
		System.out.print("  Expand " + node.getState() + ":");
		for (int i = 0; i < g.getNumNodes(); i++) {
			if (adj[k][i] != 0){
				s = listNodes.get(i);
				s.setGCost(node.getGCost() + adj[k][i]);
				listNodes.set(i, s);			//
				sucessors.add(s);
			System.out.print(" {"+s.getState() + ":" + s.getGCost() + "} ");
			}
		}
		System.out.println();
		
		return sucessors;
	}
	

	private void solutionOutput(Node node, Graph g) {
				
		ArrayList<Node> list = new ArrayList<Node>();
		
		Node pNode = g.getGoalS();		
		while (pNode != null) {
			list.add(pNode);
			pNode = pNode.getParent();
		}
				
		Collections.reverse(list);
		
		System.out.println("Output: " + g.getAlgo() + ":");
		if (g.getAlgo().equals("BFS") || g.getAlgo().equals("DFS") ) {
		
			for (int i = 0; i < list.size(); i++)
				System.out.println(list.get(i).getState() + " " + list.get(i).getDepth());
			output1(list);
		} else if (g.getAlgo().equals("UCS")) {
			for (int i = 0; i < list.size(); i++)
				System.out.println(list.get(i).getState() + " " + list.get(i).getGCost());
			output2(list);
		} else if (g.getAlgo().equals("A*")) {
			for (int i = 0; i < list.size(); i++)
				System.out.println(list.get(i).getState() + " " + list.get(i).getGCost());
			output2(list);
		} 
	}
	
	private void output1(ArrayList<Node> list){
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt"),"utf-8"))){
			for (int i = 0; i < list.size(); i++){
				writer.write(list.get(i).getState() + " " + list.get(i).getDepth()+"\n");
			}
		} catch (IOException ex){
			ex.printStackTrace();
		}
	}
	private void output2(ArrayList<Node> list){
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt"),"utf-8"))){
			for (int i = 0; i < list.size(); i++){
				writer.write(list.get(i).getState() + " " + list.get(i).getGCost()+"\n");
			}
		} catch (IOException ex){
			ex.printStackTrace();
		}
	}
	
	private Node findNode(Queue<Node> list, Node new_node) {
		Iterator<Node> cTemp = list.iterator();
		Node temp = null;
		while (cTemp.hasNext()) {
			temp = cTemp.next();
			if (temp.getState().equals(new_node.getState()) && (temp.getId() == new_node.getId())) {
				return temp;
			}
		}
		return null;
	}
	
	private static Comparator<Node> compA = new Comparator<Node>() {

		@Override
		public int compare(Node c1, Node c2) {
			if (c1.getfCost() == c2.getfCost())
				return (c1.getPriority() - c2.getPriority());
			return (int) (c1.getfCost() - c2.getfCost());
		}
	};
	
	private static Comparator<Node> compUCS = new Comparator<Node>() {

		@Override
		public int compare(Node c1, Node c2) {
			if (c1.getGCost() == c2.getGCost())
				return (c1.getPriority() - c2.getPriority());
			return (int) (c1.getGCost() - c2.getGCost());
		}
	};
}
