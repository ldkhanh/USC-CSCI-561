package aiHW01;

import java.util.*;

public class TestPQ2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Queue<Node> fn = new PriorityQueue<Node>(50, compUCS);
		
		fn.offer(new Node(1,1,"A",3,8));
		Node bt = new Node(2,2,"B",1,9);
		fn.offer(bt);
		fn.offer(new Node(3,3,"C",5,9));
		fn.offer(new Node(4,4,"D",2,33));
		fn.offer(new Node(5,5,"E",8,44));
		fn.offer(new Node(6,6,"K",1,3));
		fn.offer(new Node(7,7,"F",6,5));
		
		fn.remove();
		Node bt2 = new Node(bt.getId(),8, bt.getState(), bt.getGCost(), bt.getHCost());
		fn.offer(bt2);

		
		SortedSet<Node> sorter = new TreeSet<Node>(new Comparator<Node>() {
			@Override
			public int compare(Node a, Node b) {
				if (a.getGCost() == b.getGCost()) {
					return (a.getPriority() - b.getPriority());
				}
				return ((a.getGCost()) - (b.getGCost()));
			}
		});

		sorter.addAll(fn);
		fn.removeAll(sorter);
		fn.addAll(sorter);
		
		
		
		Iterator<Node> t1 = fn.iterator();
		
		while (t1.hasNext()) {
			Node temp = t1.next();
			System.out.println(temp.getState() + ":" + temp.getGCost());
		}
	}
	public static Comparator<Node> compUCS = new Comparator<Node>() {

		@Override
		public int compare(Node c1, Node c2) {
			if (c1.getGCost() == c2.getGCost())
				return (c1.getPriority() - c2.getPriority());
			return (int) (c1.getGCost() - c2.getGCost());
		}
	};

}
