package aiHW01;

import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.SortedSet;
import java.util.TreeSet;

public class Test4 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Node> fn = new PriorityQueue<Node>(20,comp);

		fn.offer(new Node(1,1,"A",3,8));
		Node bt = new Node(2,2,"B",2,9);
		fn.offer(bt);
		fn.offer(new Node(3,3,"C",5,9));
		fn.offer(new Node(4,4,"D",2,33));
		fn.offer(new Node(5,5,"E",8,44));
		fn.offer(new Node(6,6,"K",1,3));
		fn.offer(new Node(7,7,"F",6,5));

		fn.remove(bt);
		Node bt2 = new Node(bt.getId(),8, bt.getState(), bt.getGCost(), bt.getHCost());
		fn.offer(bt2);
		
		

		SortedSet<Node> sorter = new TreeSet<Node>(new Comparator<Node>() {
			@Override
			public int compare(Node a, Node b) {
				if ((a.getGCost() + a.getHCost()) == (b.getGCost() + b.getHCost())) {
					return (a.getPriority() - b.getPriority());
				}
	
					return ((a.getGCost() + a.getHCost()) - (b.getGCost() + b.getHCost()));
			}
		});
		
		

		sorter.addAll(fn);
		fn.clear();
		fn.addAll(sorter);

		Iterator<Node> t1 = fn.iterator();

		while (t1.hasNext()) {
			Node temp = t1.next();
//			int k = temp.getGCost() + temp.getHCost();
			System.out.println(temp.getState() + ":" + temp.getfCost());
		}

	}
	
	public static Comparator<Node> comp = new Comparator<Node>() {

		@Override
		public int compare(Node a, Node b) {
			if ((a.getGCost() + a.getHCost()) == (b.getGCost() + b.getHCost())) {
				return (a.getPriority() - b.getPriority());
			}
			return (int) ((a.getGCost() + a.getHCost()) - (b.getGCost() + b.getHCost()));
		}
	};
}
