package aiHW01;

public class LiveTraffic {

	private String lines;

	public LiveTraffic(String lines) {
		this.lines = lines;
	}

	public String getLine() {
		return this.lines;
	}

	public String getFirstS() {
		String[] temp = this.lines.split(" ");
		return temp[0];
	}

	public String getSecondS() {
		String[] temp = this.lines.split(" ");
		return temp[1];
	}

	public int getTravelTime() {
		String[] temp = this.lines.split(" ");
		try {
			return Integer.parseInt(temp[2].replaceAll("\\s", ""));
		} catch (NumberFormatException e) {
			return -1;
		}
	}

}
