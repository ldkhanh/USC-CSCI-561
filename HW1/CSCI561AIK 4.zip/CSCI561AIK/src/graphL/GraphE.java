package graphL;

import java.util.*;
import java.io.*;

public class GraphE {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Scanner s = new Scanner(new File("data.txt"));
			StringTokenizer  t = new StringTokenizer(s.nextLine());
			Hashtable<Integer,Node> nodes = new Hashtable<Integer,Node>();
			
			while (t.hasMoreTokens()) {
				int id = Integer.parseInt(t.nextToken());
				nodes.put(id, new Node(id));
			}
			
			while (s.hasNextLine()) {
				Node e1 = nodes.get(s.nextInt());
				Node e2 = nodes.get(s.nextInt());
				
				e1.adjacent.add(e2);
				e2.adjacent.add(e1);
			}
			
			List<Node> adjencyNodeList = new ArrayList(nodes.values());
			
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}

class Node {
	int id;
	List<Node> adjacent = new ArrayList<Node>();
	public Node(int id) {
		this.id = id;
	}
	
}
