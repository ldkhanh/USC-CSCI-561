package aiHW01;

public class TestIO {
	public static void main(String[] args) {
		GraphIO g = new GraphIO();
		g.buildData();	
	}
}
