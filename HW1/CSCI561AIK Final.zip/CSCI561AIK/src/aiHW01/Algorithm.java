package aiHW01;

import java.io.*;
import java.util.*;

public class Algorithm {

	private Queue<Node> frontierB;
	private Deque<Node> frontierD;
	private Queue<Node> frontierU;
	private Queue<Node> exploredSet;

	public Algorithm() {
		this.frontierB = new LinkedList<Node>();
		this.frontierD = new LinkedList<Node>();
		this.exploredSet = new LinkedList<Node>();

	}

	public void BFS(Graph problem) {

		frontierB.offer(problem.getStartS());
		Node node, new_node;
		ArrayList<Node> childNode = new ArrayList<Node>();

		while (true) {
			if (frontierB.isEmpty())
				return;

			//// -----------Print frontier----------///
			Iterator<Node> tt = frontierB.iterator();
			System.out.print("Fronier list: ");
			while (tt.hasNext()) {
				System.out.print("  " + tt.next().getState());
			}
			System.out.println();
			// --------------------------///

			node = this.frontierB.poll();

			if (problem.getGoalS().getState().equals(node.getState())) {
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			childNode = expandNode(node, problem);
			System.out.print("  Add child : ");

			for (int i = 0; i < childNode.size(); i++) {
				new_node = childNode.get(i);
				if (!frontierB.contains(new_node) && !exploredSet.contains(new_node)) {
					insertBFS(node,new_node,problem);
					System.out.print("{ " + problem.getListNodes().get(new_node.getId()).getState() + 
							" <-- " + problem.getListNodes().get(new_node.getId()).getParent().getState() + "}  ");
				} else {
					 System.out.print("Not["+problem.getListNodes().get(new_node.getId()).getState()+"] ");
				}
			}
			System.out.println("");
		}

	}

	public void DFS(Graph problem) {

		frontierD.push(problem.getStartS());
		Node node, new_node;
		ArrayList<Node> childNode = new ArrayList<Node>();

		while (true) {
			if (frontierD.isEmpty())
				return;

			//// -----------Print frontier----------///
			Iterator<Node> tt = frontierD.iterator();
			System.out.print("Fronier list: ");
			while (tt.hasNext()) {
				System.out.print("  " + tt.next().getState());
			}
			System.out.println();
			// --------------------------///

			node = frontierD.pop();
			if (problem.getGoalS().getState().equals(node.getState())) {
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			childNode = expandNode(node, problem);
			Collections.reverse(childNode);

			System.out.print("  Add child : ");
			for (int i = 0; i < childNode.size(); i++) {
				new_node = childNode.get(i);
				if (!frontierD.contains(new_node) && !exploredSet.contains(new_node)) {
					insertDFS(node,new_node,problem);
					System.out.print("{ " + problem.getListNodes().get(new_node.getId()).getState() + 
							" <-- " + problem.getListNodes().get(new_node.getId()).getParent().getState() + "}  ");
				} else {
					 System.out.print("Not["+problem.getListNodes().get(new_node.getId()).getState()+"] ");
				}
			}
			System.out.println("");
		}
	}

	public void UCS(Graph problem) {
		this.frontierU = new PriorityQueue<Node>(problem.getNumNodes(), compUCS);
		frontierU.offer(problem.getStartS());
		Node node = problem.getStartS();
		Node new_node = null, temp = null;
		ArrayList<Node> childNode = new ArrayList<Node>();

		while (true) {
			if (frontierU.isEmpty())
				return;

			//// -----------Print frontier----------///
			Iterator<Node> tt = frontierU.iterator();
			System.out.println();
			System.out.print("Fronier list1: ");

			while (tt.hasNext()) {
				temp = tt.next();
				System.out.print("  " + temp.getState() +":"+ temp.getGCost());
			}
			System.out.println();
			// --------------------------///

			node = this.frontierU.poll();
			if (problem.getGoalS().getState().equals(node.getState())) {
				solutionOutput(node, problem);
				return;
			}
			this.exploredSet.add(node);
			
			childNode = expandNode(node, problem);

			System.out.print("  Add child : ");

			for (int i = 0; i < childNode.size(); i++) {
				new_node = childNode.get(i);
				if (!frontierU.contains(new_node) && !exploredSet.contains(new_node)) {
					insertNodeU(node, new_node, problem);
					System.out.print("{ " + problem.getListNodes().get(new_node.getId()).getState() + 
							" <-- " + problem.getListNodes().get(new_node.getId()).getParent().getState() + "}  ");
				} else if (frontierU.contains(new_node)) {
					temp = findNode(frontierU, new_node);
					if (temp.getGCost() > new_node.getGCost()) {
						frontierU.remove(temp);
						updateNodeU(node, new_node, problem);
						System.out.print("  Update1 [" + problem.getListNodes().get(new_node.getId()).getState() + 
								":" +  problem.getListNodes().get(new_node.getId()).getGCost() +
								" <--" + problem.getListNodes().get(new_node.getId()).getParent().getState() + "]");

					}
				} else if (exploredSet.contains(new_node)) {
					temp = findNode(exploredSet, new_node);
					if (temp.getGCost() > new_node.getGCost()) {
						exploredSet.remove(temp);
						updateNodeU(node, new_node, problem);
						System.out.print("  Update2 [" + problem.getListNodes().get(new_node.getId()).getState() + 
								":" +  problem.getListNodes().get(new_node.getId()).getGCost() +
								" <--" + problem.getListNodes().get(new_node.getId()).getParent().getState()  + "]");
					}
				}
			}
			System.out.println("");

			SortedSet<Node> sorter = new TreeSet<Node>(new Comparator<Node>() {
				@Override
				public int compare(Node a, Node b) {
					if (a.getGCost() == b.getGCost()) {
						return (a.getPriority() - b.getPriority());
					}
					return ((a.getGCost()) - (b.getGCost()));
				}
			});

			sorter.addAll(frontierU);
			frontierU.removeAll(sorter);
			frontierU.addAll(sorter);

		}

	}

	public void Astar(Graph problem) {
		this.frontierU = new PriorityQueue<Node>(problem.getNumNodes(), compA2);
		frontierU.offer(problem.getStartS());
		Node node = problem.getStartS();
		Node new_node, temp;
		ArrayList<Node> childNode = new ArrayList<Node>();

		while (true) {
			if (frontierU.isEmpty())
				return;

			//// -----------Print frontier----------///
			Iterator<Node> tt = frontierU.iterator();
			System.out.print("A* Fronier list: ");
			int f= 0;
			while (tt.hasNext()) {
				temp = tt.next();
				f = temp.getGCost() + temp.getHCost();
				System.out.print("  " + temp.getState() +":"+ f);
			}
			System.out.println();
			// --------------------------///

			node = this.frontierU.poll();

			if (problem.getGoalS().getState().equals(node.getState())) {
				solutionOutput(node, problem);
				return;
			}
//			Node nE = problem.getListNodes().get(node.getId());
			this.exploredSet.add(node);
			
			//// -----------Print ExploredSet----------///
			Iterator<Node> te = exploredSet.iterator();
			System.out.println();
			System.out.print("ExploredSet: ");

			while (te.hasNext()) {
				temp = te.next();
				System.out.print("  " + temp.getState() + ":" + temp.getGCost());
			}
			System.out.println();
			// --------------------------///
			
			
			childNode = expandNode(node, problem);
			System.out.print("  Add child : ");

			for (int i = 0; i < childNode.size(); i++) {
				new_node = childNode.get(i);
				if (!frontierU.contains(new_node) && !exploredSet.contains(new_node)) {
					insertNodeU(node, new_node, problem);
					System.out.print("{ " + problem.getListNodes().get(new_node.getId()).getState() + 
							" <-- " + problem.getListNodes().get(new_node.getId()).getParent().getState() + "}  ");

				} else if (frontierU.contains(new_node)) {
					temp = findNode(frontierU, new_node);
					if ( (temp.getGCost() + temp.getHCost()) > (new_node.getGCost() + new_node.getHCost())) {
						frontierU.remove(temp);
						updateNodeU(node, new_node, problem);
						System.out.print("  Update1 [" + problem.getListNodes().get(new_node.getId()).getState() + 
								":" +  problem.getListNodes().get(new_node.getId()).getGCost() +
								" <--" + problem.getListNodes().get(new_node.getId()).getParent().getState() + "]");
					}
				} else if (exploredSet.contains(new_node)) {
					temp = findNode(exploredSet, new_node);
					if ((temp.getGCost() + temp.getHCost()) > (new_node.getGCost() + new_node.getHCost())) {
						exploredSet.remove(temp);
						updateNodeU(node, new_node, problem);
						System.out.print("  Update2 [" + problem.getListNodes().get(new_node.getId()).getState() + 
								":" +  problem.getListNodes().get(new_node.getId()).getGCost() +
								" <--" + problem.getListNodes().get(new_node.getId()).getParent().getState()  + "]");
					}
				}

			}
			System.out.println("");

			SortedSet<Node> sorter = new TreeSet<Node>(new Comparator<Node>() {
				@Override

				public int compare(Node a, Node b) {
					if ( (a.getGCost() + a.getHCost()) == (b.getGCost() + b.getHCost())) {
						return (a.getPriority() - b.getPriority());
					}
					return ((a.getGCost() + a.getHCost()) - (b.getGCost() + b.getHCost()));
				}
			});

			sorter.addAll(frontierU);
			frontierU.clear();
			frontierU.addAll(sorter);
		}
	}

	private void insertBFS(Node node, Node new_node, Graph g) {

		Node temp = new Node(new_node.getId(), new_node.getPriority(), new_node.getState(), new_node.getGCost(),
				new_node.getHCost());
		temp.setParent(node);
		temp.setDepth(node.getDepth() + 1);

		frontierB.offer(temp);		
		Node n = g.getListNodes().get(new_node.getId());
		n.setParent(node);
		n.setDepth(node.getDepth() + 1);
	}
	
	private void insertDFS(Node node, Node new_node, Graph g) {

		Node temp = new Node(new_node.getId(), new_node.getPriority(), new_node.getState(), new_node.getGCost(),
				new_node.getHCost());
		temp.setParent(node);
		temp.setDepth(node.getDepth() + 1);

		frontierD.push(temp);	
		Node n = g.getListNodes().get(new_node.getId());
		n.setParent(node);
		n.setDepth(node.getDepth() + 1);
	}
	
	private void insertNodeU(Node node, Node new_node, Graph g) {

		Node temp = new Node(new_node.getId(), new_node.getPriority(), new_node.getState(), new_node.getGCost(),
				new_node.getHCost());
		temp.setParent(node);
		temp.setDepth(node.getDepth() + 1);
		temp.setGCost(node.getGCost() + g.getTTime(node.getId(), new_node.getId()));

		frontierU.offer(temp);
		
		Node n = g.getListNodes().get(new_node.getId());
		n.setParent(node);
		n.setDepth(node.getDepth() + 1);
		n.setGCost(node.getGCost() + g.getTTime(node.getId(), new_node.getId()));
	}

	private void updateNodeU(Node node, Node new_node, Graph g) {

		Node temp = new Node(new_node.getId(), g.getNumNodes(), new_node.getState(), new_node.getGCost(),
				new_node.getHCost());
		temp.setParent(node);
		temp.setDepth(node.getDepth() + 1);
		temp.setGCost(node.getGCost() + g.getTTime(node.getId(), new_node.getId()));

		frontierU.offer(temp);
		
		Node n = g.getListNodes().get(new_node.getId());
		n.setParent(node);
		n.setDepth(node.getDepth() + 1);
		n.setGCost(node.getGCost() + g.getTTime(node.getId(), new_node.getId()));

	}

	private ArrayList<Node> expandNode(Node node, Graph g) {
		ArrayList<Node> sucessors = new ArrayList<Node>();
		Node s;
		int adj[][] = g.getAdjG();
		ArrayList<Node> listNodes = g.getListNodes();

/*		System.out.print("List Nodes 1: ");
		for (int i = 0; i < listNodes.size(); i++)
			System.out.print("{" + listNodes.get(i).getState() + ":" + listNodes.get(i).getGCost() + "} ");
		System.out.println();*/

		int k = node.getId();

		System.out.print("  Expand " + node.getState() + ":");
		for (int i = 0; i < g.getNumNodes(); i++) {
			if (adj[k][i] >= 0) {
				s = listNodes.get(i);
				Node n = new Node(s.getId(), s.getPriority(),s.getState(),node.getGCost() + adj[k][i], s.getHCost());
				sucessors.add(n);
				System.out.print(" {" + s.getState() + ":" + s.getGCost() + "} ");
			}
		}
		System.out.println();

		return sucessors;
	}

	private void solutionOutput(Node node, Graph g) {

		ArrayList<Node> list = new ArrayList<Node>();

		Node pNode = g.getGoalS();
		while (pNode != null) {
			list.add(pNode);
			pNode = pNode.getParent();
		}

		Collections.reverse(list);

		System.out.println("Output: " + g.getAlgo() + ":");
		if (g.getAlgo().equals("BFS") || g.getAlgo().equals("DFS")) {

			for (int i = 0; i < list.size(); i++)
				System.out.println(list.get(i).getState() + " " + list.get(i).getDepth());
			output1(list);
		} else if (g.getAlgo().equals("UCS")) {
			for (int i = 0; i < list.size(); i++)
				System.out.println(list.get(i).getState() + " " + list.get(i).getGCost());
			output2(list);
		} else if (g.getAlgo().equals("A*")) {
			for (int i = 0; i < list.size(); i++)
				System.out.println(list.get(i).getState() + " " + list.get(i).getGCost());
			output2(list);
		}
	}

	private void output1(ArrayList<Node> list) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt"), "utf-8"))) {
			for (int i = 0; i < list.size(); i++) {
				writer.write(list.get(i).getState() + " " + list.get(i).getDepth() + "\n");
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private void output2(ArrayList<Node> list) {
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("output.txt"), "utf-8"))) {
			for (int i = 0; i < list.size(); i++) {
				writer.write(list.get(i).getState() + " " + list.get(i).getGCost() + "\n");
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	private Node findNode(Queue<Node> list, Node new_node) {
		Iterator<Node> cTemp = list.iterator();
		Node temp = null;
		while (cTemp.hasNext()) {
			temp = cTemp.next();
			if (temp.getState().equals(new_node.getState()) && (temp.getId() == new_node.getId())) {
				return temp;
			}
		}
		return null;
	}

	private static Comparator<Node> compA2 = new Comparator<Node>() {

		@Override
		public int compare(Node c1, Node c2) {
			if ((c1.getGCost() + c1.getHCost()) == (c2.getGCost() + c2.getHCost()))
				return (c1.getPriority() - c2.getPriority());
			return (int) ((c1.getGCost() + c1.getHCost()) - (c2.getGCost() + c2.getHCost()));
		}
	};

	private static Comparator<Node> compUCS = new Comparator<Node>() {

		@Override
		public int compare(Node c1, Node c2) {
			if (c1.getGCost() == c2.getGCost())
				return (c1.getPriority() - c2.getPriority());
			return (int) (c1.getGCost() - c2.getGCost());
		}
	};
}
