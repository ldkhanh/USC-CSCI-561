package aiHW01;

import java.util.*;

public class Node implements Comparator<Node> {
	
	private int id;
	private int priority;
	private String state = null;
	private Node parent = null;
	private int Depth = 0;
	private int gCost = 0;			
	private int hCost = 0;
	
	public Node(){
		
	}
	
	public Node(int id) {
		this.setId(id);
	}
	
	public Node(String state){
		this.setState(state);
	}
	public Node(int id, String state) {
		this.setState(state);
		this.setId(id);
	}
	
	public Node(int id, int priority, String state) {
		this.setState(state);
		this.setId(id);
		this.setPriority(priority);
	}
	
	public Node(int id, String state, int pcost){
		this.setId(id);
		this.setState(state);
		this.setGCost(pcost);
	}
	
	public Node(int id, String state, int pcost, int hCost){
		this.setId(id);
		this.setState(state);
		this.setGCost(pcost);
		this.setHCost(hCost);
	}
	
	public Node(int id, int priority, String state, int pcost, int hCost){
		this.setId(id);
		this.setPriority(priority);
		this.setState(state);
		this.setGCost(pcost);
		this.setHCost(hCost);
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Node getParent() {
		return parent;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	@Override
	public boolean equals(Object o) {
		if (o != null && (o instanceof Node) && ((Node)o).getState() == this.getState())
			return true;
		if (o != null && (o instanceof Node) && ((Node)o).getId() == this.getId())
			return true;
		
		return false;
	}

	@Override
	public int hashCode(){
		return this.getId();
	}
	
	@Override
	public int compare(Node node1, Node node2) {
		if (node1.getGCost() == node2.getGCost())
			return (node1.getId() - node2.getId());
		return (node1.getGCost()- node2.getGCost());   
	}
	
	public int getGCost() {
		return gCost;
	}

	public void setGCost(int gCost) {
		this.gCost = gCost;
	}

	public int getHCost() {
		return hCost;
	}

	public void setHCost(int hCost) {
		this.hCost = hCost;
	}

	public int getDepth() {
		return Depth;
	}

	public void setDepth(int depth) {
		Depth = depth;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
}
