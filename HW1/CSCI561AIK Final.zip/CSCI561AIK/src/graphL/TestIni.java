package graphL;

public class TestIni {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[][] a = new int[10][10];
		
		for (int i = 0; i < 10*10; i++) {
			a[i/10][i%10] = -1;
		}
		
		for (int i = 0; i < 10; i++) {
			System.out.println();
			for (int j = 0; j < 10; j++)
			{
				System.out.print("  "+a[i][j]);
			}
		}
		
	}

}
