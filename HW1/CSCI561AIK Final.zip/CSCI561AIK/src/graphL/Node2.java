package graphL;

import java.util.*;
//public class Node2 implements Comparator<Node2> {
public class Node2 {	

	private int id;
	private int priority;
	private String state = null;
	private Node2 parent = null;
	private int Depth = 0;
	private int gCost = 0;			
	private int hCost = 0;
	private int fCost = 0;
	
	public Node2(){
		
	}
	
	public Node2(int id) {
		this.setId(id);
	}
	
	public Node2(String state){
		this.setState(state);
	}
	public Node2(int id, String state) {
		this.setState(state);
		this.setId(id);
	}
	
	public Node2(int id, int priority, String state) {
		this.setState(state);
		this.setId(id);
		this.setPriority(priority);
	}
	
	public Node2(int id, String state, int pcost){
		this.setId(id);
		this.setState(state);
		this.setGCost(pcost);
		this.setfCost();
	}
	
	public Node2(int id, String state, int pcost, int hCost){
		this.setId(id);
		this.setState(state);
		this.setGCost(pcost);
		this.setHCost(hCost);
		this.setfCost();
	}
	
	public Node2(int id, int priority, String state, int pcost, int hCost){
		this.setId(id);
		this.setPriority(priority);
		this.setState(state);
		this.setGCost(pcost);
		this.setHCost(hCost);
		this.setfCost();
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Node2 getParent() {
		return parent;
	}

	public void setParent(Node2 parent) {
		this.parent = parent;
	}

/*	@Override
	public boolean equals(Object o) {
		if (o != null && (o instanceof Node2) && ((Node2)o).getState() == this.getState())
			return true;
		if (o != null && (o instanceof Node2) && ((Node2)o).getId() == this.getId())
			return true;
		
		return false;
	}

	@Override
	public int hashCode(){
		return this.getId();
	}
	
	@Override
	public int compare(Node2 node1, Node2 node2) {
		if (node1.getGCost() == node2.getGCost())
			return (node1.getId() - node2.getId());
		return (node1.getGCost()- node2.getGCost());   /// need change to getGCost()
	}*/
	
	public int getGCost() {
		return gCost;
	}

	public void setGCost(int gCost) {
		this.gCost = gCost;
		this.setfCost();
	}

	public int getHCost() {
		return hCost;
	}

	public void setHCost(int hCost) {
		this.hCost = hCost;
	}

	public int getDepth() {
		return Depth;
	}

	public void setDepth(int depth) {
		Depth = depth;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public int getfCost() {
		return fCost;
	}

	public void setfCost() {
		this.fCost = this.gCost + this.hCost;
	}
}

