package aiHW01;

import java.io.*;
import java.util.*;

public class GraphIO {

	public static void main(String[] args) {
		
		input();
	}
	public static void input()
	{
		String ALGO = null, StartS = null, GoalS = null, numLT = null, numST = null;
		int numLiveTraffic = 0; 
		int numSundayTraffic = 0;
		int numNodes = 0;
		BufferedReader br = null;
		String[] tokens;
		String[] tLine;
		int[][] graph;
		ArrayList<Node> nodes = new ArrayList<Node>();
		Map<String,Integer> nodesMap = new LinkedHashMap<String,Integer>();
		Set<String> lNodes = new LinkedHashSet();
		
		try {
			br = new BufferedReader(new FileReader("input.txt"));
			
			ALGO = br.readLine();
			StartS = br.readLine();
			GoalS = br.readLine();
			numLT = br.readLine();
			if (numLT != null && numLT.matches("[0-9]+") && numLT.length()>0)
				numLiveTraffic = Integer.parseInt(numLT);

			System.out.println("Algorithm: " + ALGO);
			System.out.println("Start State: " + StartS);
			System.out.println("End State: " + GoalS);
			System.out.println("Number Live Traffic Line: " + numLiveTraffic);

			tLine = new String[numLiveTraffic];
			for (int i = 0; i < numLiveTraffic; i++) {
				tLine[i] = br.readLine();
				tokens = tLine[i].split(" ");
				System.out.println(tokens[0] + " ---> " + tokens[1] + " : " + tokens[2]);
				lNodes.add(tokens[0]);
				lNodes.add(tokens[1]);
			}			
			numNodes = lNodes.size();
			int j=0;
			String temp;
			Iterator it = lNodes.iterator();
			while (it.hasNext()) {
				temp = (String)it.next();
				nodesMap.put(temp, j++);
				nodes.add(new Node(temp));
			}
			graph = new int[numNodes][numNodes];
			for (int i = 0; i < numLiveTraffic; i++) {
				tokens = tLine[i].split(" ");
	//			System.out.println((int)nodesMap.get((String)tokens[0]) + " ---> " + (int)nodesMap.get((String)tokens[1]) + "  : " +tokens[2]);
				graph[(int)nodesMap.get((String)tokens[0])][(int)nodesMap.get((String)tokens[1])] = Integer.parseInt(tokens[2]);
			}	
			
			
			System.out.println("List nodes in Map: " + nodesMap);
			System.out.print(" ");
			for (int i = 0; i < numNodes; i++)
				System.out.print("    " + nodes.get(i).getState());
			System.out.println();
			for (int i = 0; i < numNodes; i++){
				System.out.print(nodes.get(i).getState());
				for (int k = 0; k < numNodes; k++)
					System.out.print("    "+ graph[i][k]);
				System.out.println();
			}
			
			// ----------Sunday Traffic Lines------------
			numST = br.readLine();
			if (numST != null && numST.matches("[0-9]+") && numST.length()>0)
				numSundayTraffic = Integer.parseInt(numST);
			
			System.out.println("Number Sunday Traffic Line: " + numSundayTraffic);
			String sLine;
			for (int i = 0; i < numSundayTraffic; i++) {
				sLine = br.readLine();
				tokens = sLine.split(" ");
				System.out.println(tokens[0] + " : " + tokens[1]);
				for (int k = 0; k < nodes.size(); k++)
					if (nodes.get(k).getState().equals(tokens[0]))
						nodes.get(k).setHCost(Integer.parseInt(tokens[1]));
			}
			for (int i = 0; i < numNodes; i++)
				System.out.println("Nodes " + nodes.get(i).getState() + " h = " + nodes.get(i).getHCost());
			
	
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		 
	}

}
