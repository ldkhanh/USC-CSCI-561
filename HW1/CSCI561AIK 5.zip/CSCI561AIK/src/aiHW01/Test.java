package aiHW01;

public class Test {

	public static void main(String[] args) {
		
		Graph g = new Graph();
		g.buildData();
				
		Algorithm search = new Algorithm();
		String algo = g.getAlgo();
		switch (algo) {
		case "BFS" :
			search.BFS(g);
			break;
		case "DFS":
			search.DFS(g);
			break;
		case "UCS":
			search.UCS(g);
			break;
		case "A*":
			search.Astar(g);
			break;
		default:
			System.out.println("Input file is not compatible with given format");
			break;
		}
	}

}
